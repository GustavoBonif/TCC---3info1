<?php

include ('cabecalho.php');


?>



<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" type="text/css" href="css.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

  </head>
  <body>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>




        <!-- INICIO SE O USUARIO FOR ADM OU FUNC -->


    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
          <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Cadastro de Notícias</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                  </button>
              </div>
              <form method="post" action="<?php echo site_url('CrudController/createNoticia')?>" enctype="multipart/form-data">
                  <div class="modal-body">        
                      <div class="form-group">
                          <label for="exampleInputnome1">Nome</label>
                          <input type="nome" required class="form-control" name="nome" id="exampleInputNome1" aria-describedby="nomeHelp" placeholder="Digite o título">
                      </div>
                      <div class="form-group">
                          <label for="exampleInputTexto1">Chamada da Notícia</label>
                          <input type="text" required class="form-control" name="texto" id="exampleInputTexto1" aria-describedby="textoHelp" placeholder="Digite o texto">
                      </div>
                      <div class="form-group">
                          <label for="exampleInputImagem1">Imagem</label>
                          <input type="file" required class="form-control" name="imagemNoticia" id="imagemNoticia" aria-describedby="imagemHelp" placeholder="Selecione a imagem">
                          <input type="hidden" name="MAX_FILE_SIZE" value="30000" />
                      </div>
                      <div class="form-group">
                          <label for="exampleInputLink1">Link</label>
                          <input type="text" required class="form-control" name="link" id="exampleInputLink1" aria-describedby="imagemHelp" placeholder="Indique a URL">
                          <input type="hidden" name="MAX_FILE_SIZE" value="30000" />
                      </div>                 
                  </div>
                      <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                          <button type="submit" class="btn btn-primary" value="save">Enviar</button>
                      </div>
                  </div>
              </form>
          </div>
      </div>


        <!-- FIM SE O USUARIO FOR ADM OU FUNC-->






<div class="areaCards">
  <div class="container">
    <div class="row d-flex">

      <div class="tituloNoticias">Notícias</div>


<?php
    if(isset($_SESSION['user'])){
        if($_SESSION['user']['fk_codtipuser'] == 3 or $_SESSION['user']['fk_codtipuser'] == 2){ ?>
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" style="
    margin: 0 auto; ">
        Adicionar Notícia
        </button>
    <?php
    }
  }
?>


      <div class="row justify-content-around" style="margin-top: 5%">

<!-- 


            <?php foreach($result as $row) {?>
                <tr>
                    <th scope="row"><?php echo $row->codnoticia; ?></th>
                    <td><?php echo $row->nome; ?></td>
                    <td><?php echo $row->texto; ?></td>
                    <td> <a href="<?php echo site_url('CrudController/editNoticias');?>/<?php echo $row->codnoticia;?>">Editar</a> | <a href="<?php echo site_url('CrudController/deleteNoticias');?>/<?php echo $row->codnoticia;?>">Delete</a> </td>
                </tr>
            <?php } ?>
    -->
        <?php foreach($result as $row) {?>
          <div class="col-6" style="margin-bottom:2%; width: 80em; height: auto;">
            <a href="<?php echo $row->link_noticias; ?>" style="text-decoration: none">
              <div class="card mb-3" style="max-width: 540px; border: 1px solid #d0e5fb; border-radius: 0px;">
                <div class="row no-gutters">                 
                  <div class="col-md-7" style="padding: 2%">
                    <div class="card-body">
                      <!-- <p class="card-text"><small class="text-muted" style="font-size: 15px; opacity: 1;">Last updated 3 mins ago</small></p>
 -->
                  <?php
                      if(isset($_SESSION['user'])){
                          if($_SESSION['user']['fk_codtipuser'] == 2 or $_SESSION['user']['fk_codtipuser'] == 3){ ?>
                              <div style="margin-bottom: 3%">               
                              <a href="<?php echo site_url('CrudController/editNoticias');?>/<?php echo $row->pk_codnoticia;?>" >Editar</a> | <a href="<?php echo site_url('CrudController/deleteNoticias');?>/<?php echo $row->pk_codnoticia;?>">Deletar</a>
                            </div>
                      <?php 
                      }
                    }
                  ?>

                      <a href="<?php echo $row->link_noticias; ?>" style="text-decoration: none">
                    <hr>
                      <h5 class="card-title" style="line-height: 1.5; color: #39345a;"><?php echo mb_strimwidth($row->nome_noticias, 0, 50,"..."); ?></h5>
                      <p class="card-text" style="font-size: 15px; line-height: 1.8; font-weight: 400; color: #7782aa;"><?php echo mb_strimwidth($row->texto_noticias, 0, 90,"..."); ?></p>
                    
                    </div>
                      </a>
                  </div>
                  
                    <div class="col-md-5">
                    <img src="<?php echo base_url('assets/imagens/noticias')?>/<?php echo $row->imagem_noticias; ?>" class="card-img" alt="..." style="border-radius: 0px; width:100%; height: 300px">
                  </div>

                </div>
              </div>
            </a>
          </div> 

        <?php } ?>



    </div>
  </div>

</div>
</div>
</div>



<footer class="rodape">
    <div>
      <div class="coluna1">
        <h1 class="tituloRodape">Sobre nós</h1>
        <h4 class="textoRodape" > O sistema “vacinas online” foi criado por alunos do Instituto Federal Catarinense - Campus Araquari. Vendo a realidade atual do sistema público de saúde da cidade de Araquari na pauta de vacinações temos o objetivo de facilitar o acesso e a administração das vacinas tomadas pela população para ter um melhor controle das mesmas.
        </h4>
        <h4 class="textoRodape"> Além de facilitar o acesso a informação sobre quais vacinas devem ser tomadas conforme cada idade, e informar sobre doenças em surto, campanhas e etc com a aba de notícias. </h4>
      </div>

      

      <div class="coluna2">
        <h1 class="tituloRodape">Contato</h1>
        <h4 class="textoRodape" style="  font-weight: bold;"> Email vacinasonline.ifc@outlook.com </h4>
      </div>
    </div>
    
</footer>

<div class="rodapeFinal">
    <div style="text-align: center;">
        <h4 class="textoRodape">© Vacinas Online 2019. Criado por Gabrielle Oliveira, Gustavo Bonifácio e Jenifer Santos.</h4>
      </div>
    </div>
  </div>
</div>
</footer>

</html>


</body>

</html>