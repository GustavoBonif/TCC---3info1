<?php
    include('cabecalho.php');
?>



<?php 
    
    if (empty($_GET['campo_busca'])) { ?>
            <meta http-equiv="refresh" content="0; URL='<?php echo site_url('InicioController/controleCarteira');?>'"/>
<?php }else{

    foreach($todos as $row) {
        if($row->fk_codtipuser == 1){
               
            $nome_user = $row->nome_user;
            $cod_user = $row->pk_coduser; 

            $user_array[] = "$nome_user"."-"."$cod_user"; // cria o nome + coduser. Ex: Claudia - 39
            
        }
    }
    
    // print_r($user_array);

    $users_encontrado = []; //array vazio
    
	foreach ($user_array as $user) {
        
        $nome_user_array = explode(" ", $user);
        
		$nome = strtolower($nome_user_array[0]); //nome do usuario em caixa baixa
		$busca = trim(strtolower($_GET['campo_busca']));

		if ( strpos($nome, $busca) !== false ) {
            $users_encontrado[] = $user;
            
		}

    }
    
    // echo "encontrados ";
    // print_r($users_encontrado);

    
?>

<div class="container">
        <br>
        <br>
        <p>Usuários Comum</p>


    <!-- <form method="get" action="<?php echo site_url('InicioController/buscaUserComum');?>">
        <input type="text" name="campo_busca" placeholder="Procure o nome do usuário?" autocomplete="off">
        <input type="submit" name="buscar" >
    </form> -->

    <nav class="navbar navbar-light bg-light">
      <a class="navbar-brand">Usuário Comum</a>
      <form class="form-inline" method="get" action="<?php echo site_url('InicioController/buscaUserComum');?>">
        <input class="form-control mr-sm-2" name="campo_busca" type="search" placeholder="Nome do usuário" aria-label="Pesquisar"  autocomplete="off">
        <button class="btn btn-outline-success my-2 my-sm-0 active botaoPesquisa" type="submit">Pesquisar</button>
      </form>
    </nav>

    <table class="table" style="border: 1px solid #d0e5fb !important ">
    <thead class="thead">
    <tr>
    <th scope="col">#</th>
    <th scope="col">Nome</th>
    <th scope="col">Email</th>               
    <th schope="col">Opções</th>
    
    </tr>
    </thead>
    <tbody>


    <?php foreach($todos as $row) {
            foreach ($users_encontrado as $user_busca) {
                $coduser_busca = explode("-", $user_busca);
                if($row->fk_codtipuser == 1 and $row->pk_coduser == $coduser_busca[1]){?>
    <tr>
        <th scope="row"><?php echo $row->pk_coduser; ?></th>
        <td><?php echo $row->nome_user; ?></td>
        <td><?php echo $row->email_user; ?></td>
        <td> <a href="<?php echo site_url('InicioController/carteiraComum');?>/<?php echo $row->pk_coduser;?>">Ver Carteira</a> </td>
    </tr>
    <?php }
        }
    } ?>
     </tbody>
</table>
</div>

</body>


<footer class="rodape">
    <div>
      <div class="coluna1">
        <h1 class="tituloRodape">Sobre nós</h1>
        <h4 class="textoRodape" > O sistema “vacinas online” foi criado por alunos do Instituto Federal Catarinense - Campus Araquari. Vendo a realidade atual do sistema público de saúde da cidade de Araquari na pauta de vacinações temos o objetivo de facilitar o acesso e a administração das vacinas tomadas pela população para ter um melhor controle das mesmas.
        </h4>
        <h4 class="textoRodape"> Além de facilitar o acesso a informação sobre quais vacinas devem ser tomadas conforme cada idade, e informar sobre doenças em surto, campanhas e etc com a aba de notícias. </h4>
      </div>

      

      <div class="coluna2">
        <h1 class="tituloRodape">Contato</h1>
        <h4 class="textoRodape" style="  font-weight: bold;"> Email vacinasonline.ifc@outlook.com </h4>
      </div>
    </div>
    
</footer>

<div class="rodapeFinal">
    <div style="text-align: center;">
        <h4 class="textoRodape">© Vacinas Online 2019. Criado por Gabrielle Oliveira, Gustavo Bonifácio e Jenifer Santos.</h4>
      </div>
    </div>
  </div>
</div>
</footer>

</html>

<?php
}

