<?php 
	include('cabecalho.php');
?>


<body>


		<div style="margin: 2% 20% 2% 20%">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Cadastro de Usuário</h5>
            </div>
        <!-- inicio formulário -->
        <form method="post" action="<?php echo site_url('CrudController/createComum')?>">
            <div class="modal-body">        
                <div class="form-group">
                    <label for="exampleInputnome1">Nome</label>
                    <input type="nome" required class="form-control" name="nome" id="exampleInputNome1" aria-describedby="nomeHelp" placeholder="Digite seu nome">
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Email</label>
                    <input type="email" required class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Digite seu email">
                </div>
                <div class="form-group">
                    <label for="exampleInputSenha1">Senha</label>
                    <input type="password" required class="form-control" name="senha" id="senha" placeholder="Senha">
                </div>
                <div class="form-group">
                    <label for="exampleInputSenha1">Confirme a Senha</label>
                    <input type="password" required class="form-control"  id="confirmaSenha" placeholder="Senha">
                </div>
                <div class="form-group">
                    <label for="cpf">CPF</label>
                    <input type="text" required class="form-control" maxlength="11" name="cpf" id="cpf" placeholder="CPF">
                </div>
                <div class="form-group">
                    <label for="rg">RG</label>
                    <input type="text" required class="form-control" maxlength="7" name="rg" id="rg" placeholder="RG">
                </div>
                
                <div class="form-group form-radio">
                    <input type="hidden" class="form-radio-input" value="1" name="codtipuser" checked id="exampleRadio1">
                    <label class="form-radio-label" for="exampleRadio1"></label>
                </div>

                </div>
                <div style="margin-top: -4%" class="modal-footer">
                        <a class="" href="<?php echo site_url('InicioController/index');?>">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Voltar</button>
                        </a>
                    <button type="submit" class="btn btn-primary" value="save">Enviar</button>
                </div>
            </div>
        </form>
        <!-- fim formulário -->
    </div>
    </div>

    <footer>

        <script type="text/javascript">
            
        $(document).ready(function(){
            $("#cpf").mask("000.000.000-00");
            $("#cnpj").mask("00.000.000/0000-00");
            $("#telefone").mask("(00) 0000-0000");
            $("#salario").mask("999.999.990,00", {reverse: true});
            $("#cep").mask("00.000-000");
            $("#dataNascimento").mask("00/00/0000");
            
            $("#rg").mask("999.999.999-W", {
                translation: {
                    'W': {
                        pattern: /[X0-9]/
                    }
                },
                reverse: true
            })
            
            var options = {
                translation: {
                    'A': {pattern: /[A-Z]/},
                    'a': {pattern: /[a-zA-Z]/},
                    'S': {pattern: /[a-zA-Z0-9]/},
                    'L': {pattern: /[a-z]/},
                }
            }
            
            $("#placa").mask("AAA-0000", options);
            
            $("#codigo").mask("AA.LLL.0000", options);
            
            $("#celular").mask("(00) 0000-00009");
            
            $("#celular").blur(function(event){
                if ($(this).val().length == 15){
                    $("#celular").mask("(00) 00000-0009")
                }else{
                    $("#celular").mask("(00) 0000-00009")
                }
            })
        })





    var password = document.getElementById("senha")
    , confirm_password = document.getElementById("confirmaSenha");

    function validatePassword(){
    if(password.value != confirm_password.value) {
        confirm_password.setCustomValidity("As senhas estão diferentes");
    } else {
        confirm_password.setCustomValidity('');
    }
    }

    password.onchange = validatePassword;
    confirm_password.onkeyup = validatePassword;


        </script>




        <script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.mask.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-3.3.1.min.js"></script>
        <!-- <script type="text/javascript" src="<?php echo base_url();?>assets/js/mascaraForm.js"></script> -->

    </footer>

    <footer class="rodape">
    <div>
      <div class="coluna1">
        <h1 class="tituloRodape">Sobre nós</h1>
        <h4 class="textoRodape" > O sistema “vacinas online” foi criado por alunos do Instituto Federal Catarinense - Campus Araquari. Vendo a realidade atual do sistema público de saúde da cidade de Araquari na pauta de vacinações temos o objetivo de facilitar o acesso e a administração das vacinas tomadas pela população para ter um melhor controle das mesmas.
        </h4>
        <h4 class="textoRodape"> Além de facilitar o acesso a informação sobre quais vacinas devem ser tomadas conforme cada idade, e informar sobre doenças em surto, campanhas e etc com a aba de notícias. </h4>
      </div>

      

      <div class="coluna2">
        <h1 class="tituloRodape">Contato</h1>
        <h4 class="textoRodape" style="  font-weight: bold;"> Email vacinasonline.ifc@outlook.com </h4>
      </div>
    </div>
    
</footer>

<div class="rodapeFinal">
    <div style="text-align: center;">
        <h4 class="textoRodape">© Vacinas Online 2019. Criado por Gabrielle Oliveira, Gustavo Bonifácio e Jenifer Santos.</h4>
      </div>
    </div>
  </div>
</div>
</footer>

</html>

