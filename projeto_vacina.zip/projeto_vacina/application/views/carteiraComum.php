  <?php
    include('cabecalho.php');

  ?>

  <!DOCTYPE html>


<div class="areaCards" style="margin-bottom: 5% !important" >
  <div class="container">

  <?php

      if($_SESSION['user']['fk_codtipuser'] == 1){ ?>


        <h2 class="tituloNoticias">Carteira de Vacinação</h2>
        <h4 class="tituloNoticia">Usuário: <?php echo $_SESSION['user']['nome_user'] ?></h4>

  <?php }elseif($_SESSION['user']['fk_codtipuser'] == 2){ 
          foreach ($todos as $data) {

            if ($data->pk_coduser == $idusuario) {?>

            <h4 class="tituloNoticias">Carteira de Vacinação de: <?php echo $data->nome_user ?></h4>

            <?php //echo date('d/m/Y'); ?>

            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addVacinacao" style=" margin: 0 0 3% 42%; max-width: 16%">
            Adicionar Vacinação
            </button>

            <br>

            <!-- Modal -->
        
            <div class="modal fade" id="addVacinacao" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                  <div class="modal-content">
                      <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Registrar Vacinação</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                          </button>
                      </div>
                      <form method="post" action="<?php echo site_url('CrudController/createVacinacao')?>">
                          <div class="modal-body">        
                              <div class="form-group">
                                    <div>
                                      <p>Nome da Vacina:</p>
                                      <select name="codvacina">
  <?php
                                        foreach ($vacina as $data) { 
  ?>
                                        <option value="<?php echo $data->pk_codvacina ?>"><?php echo $data->nome_vacina; ?></option>                                      
  <?php
                                        }
  ?>
                                      </select>
                                    </div>

                              </div>
                              
                              <div class="form-group">
                                  <label for="exampleInputDose1">Dose</label>
                                  <input type="number" class="form-control" name="dose" id="exampleInputDose1" aria-describedby="doseHelp" placeholder="Dose da vacina">
                              </div>
                              <!-- <div class="form-group">
                                  <label for="exampleInputData1">Data</label>
                                  <input type="date" class="form-control" name="data" id="exampleInputData1" aria-describedby="dataHelp">
                              </div> -->
  <?php
                              foreach ($func as $data) {
                                if ($data->fk_coduser == $_SESSION['user']['pk_coduser']) {
                                  $codUsuarioFunc = $data->pk_codfunc;
                                }
                              }
  ?>
                              <div class="form-group">
                                  <input type="hidden" class="form-control" name="codfunc" id="exampleInputFunc1" aria-describedby="funcHelp" value="<?php echo $codUsuarioFunc ?>">
                              </div>

  <?php
                              foreach ($comum as $data) {
                                if ($data->fk_coduser == $idusuario) {
                                  $cpf = $data->pk_cpf_usercomum;
                                  $codUsuario = $data->fk_coduser;
                                }
                              }
  ?>
                              <div class="form-group">
                                  <input type="hidden" class="form-control" name="cpf" id="exampleInputComum1" aria-describedby="comumHelp" value="<?php echo $cpf ?>">

                                  <input type="hidden" class="form-control" name="coduser" id="exampleInputCodUser1" aria-describedby="coduserHelp" value="<?php echo $codUsuario ?>">
                              </div>
                            </div>
                              <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                                  <button type="submit" class="btn btn-primary" value="save">Enviar</button>
                              </div>
                          </div>
                      </form>
                  </div>
              </div>
           

          <!-- FIM Modal -->
  <?php     }   
        }
      }
  ?>




  <?php 

     

  $codUsuarioLogado = $_SESSION['user']['pk_coduser'];
  $codUsuarioLista = $idusuario;

      /*echo "<div class='row'>";*/  //linha
      $contador = 0;
    foreach($vacinacao as $row) {
      foreach($comum as $data) {
        if ($row->fk_cpf == $data->pk_cpf_usercomum and ( $data->fk_coduser == $codUsuarioLogado or $data->fk_coduser == $codUsuarioLista) ) {
          
          $contador ++;

        }
      } 
    }


     if ($contador == 0) { ?>
     <h1 style="text-align: center;">não possui registros</h1>

<?php
     }

  foreach($comum as $data) {
 ?>
     <div class='tabelaCarteira'></div>
   
<?php


      foreach($vacinacao as $row) {

        // if ($row->fk_cpf != $data->pk_cpf_usercomum and ( $data->fk_coduser != $codUsuarioLogado or $data->fk_coduser != $codUsuarioLista) ) {
        //   echo "teste";  
            
        //     break;
        // }else 

        if ($row->fk_cpf == $data->pk_cpf_usercomum and ( $data->fk_coduser == $codUsuarioLogado or $data->fk_coduser == $codUsuarioLista) ) {

      echo "<div class='dado_carteira'>"; //dado na linha

  ?>
          
          
  <?php

              foreach($vacina as $linha) {
                if ($linha->pk_codvacina == $row->fk_codvacina) { ?>
                  <p><b>Vacina:</b> <?php echo $linha->nome_vacina; ?></p> 		
  <?php        	}
              } 
              foreach($func as $linha) {
                if ($linha->pk_codfunc == $row->fk_codfunc) { 
                  foreach($todos as $dado) { 
                    if ($linha->fk_coduser == $dado->pk_coduser) { 
  ?>
                      <p><b>Registro:</b> <?php echo $linha->pk_codfunc; ?></b> 		
                      <b>aplicada por:</b> <?php echo $dado->nome_user; ?></p>
                      <p><b>Local:</b> <?php echo $linha->localtrab_userfunc; ?></p>
  <?php	        			} 
                  }
                }
              }

              foreach($comum as $linha) {
                if ($linha->pk_cpf_usercomum == $row->fk_cpf) { 
                  foreach($todos as $dado) { 
                    if ($linha->fk_coduser == $dado->pk_coduser) { 
  ?>
                      <p><b>Paciente:</b>  <?php echo $dado->nome_user; ?></p> 		
  <?php               } 
                  }
                }
              }

  ?>	   
                <p><b>Data: </b><?php echo $row->data_vacinacao; ?></p>


                <p><b>Dose: </b><?php echo $row->dose_vacinacao; ?></p>
                  
  <?php 
                if ($_SESSION['user']['fk_codtipuser'] == 2) { 
  ?>
                  
                  <a href="<?php echo site_url('CrudController/editVacinacao');?>/<?php echo $row->pk_codvacinacao;?>">Editar</a> | <a data-toggle="modal" data-target="#modalDeleteVacinacao<?= $row->pk_codvacinacao ?>" href="#">Delete</a>

                
<!-- Modal Delete -->
                  <div class="modal fade" id="modalDeleteVacinacao<?=$row->pk_codvacinacao ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                      <div class="modal-content">
                          <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel">Tem certeza que deseja deletar esse registro?</h5>
                          </div>
                          <form method="post" action="<?php echo site_url('CrudController/deleteVacinacao');?>/<?php echo $row->pk_codvacinacao;?>">
                              <div class="modal-footer">

                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                              <button type="submit" class="btn btn-primary">Sim, deletar</button>
                              <?php
                                  echo $this->session->flashdata("erro");
                              ?>
                              </div>
                          </div>
                          </form>
                      </div>
                  </div>

<!-- FIM MODAL DELETE -->
  <?php
                }           
  ?>
                </div>
              
  <?php       	

        }

  } 
      
  ;

    /*  }*/
        
    }

  ?>  
  </div>
</div>

  </table>
</div>




 <footer class="rodape" style="margin-top: 5%;">
    <div>
      <div class="coluna1">
        <h1 class="tituloRodape">Sobre nós</h1>
        <h4 class="textoRodape" > O sistema “vacinas online” foi criado por alunos do Instituto Federal Catarinense - Campus Araquari. Vendo a realidade atual do sistema público de saúde da cidade de Araquari na pauta de vacinações temos o objetivo de facilitar o acesso e a administração das vacinas tomadas pela população para ter um melhor controle das mesmas.
        </h4>
        <h4 class="textoRodape"> Além de facilitar o acesso a informação sobre quais vacinas devem ser tomadas conforme cada idade, e informar sobre doenças em surto, campanhas e etc com a aba de notícias. </h4>
      </div>

      

      <div class="coluna2">
        <h1 class="tituloRodape">Contato</h1>
        <h4 class="textoRodape" style="  font-weight: bold;"> Email vacinasonline.ifc@outlook.com </h4>
      </div>
    </div>
    
</footer>

<div class="rodapeFinal">
    <div style="text-align: center;">
        <h4 class="textoRodape">© Vacinas Online 2019. Criado por Gabrielle Oliveira, Gustavo Bonifácio e Jenifer Santos.</h4>
      </div>
    </div>
  </div>
</div>
</footer>

</html>

  
  </body>
  </html>