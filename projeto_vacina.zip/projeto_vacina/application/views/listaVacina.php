<?php
include('cabecalho.php');


if ($_SESSION['user']['fk_codtipuser'] != 2) { ?>
    <meta http-equiv="refresh" content="0; URL='<?php echo site_url('InicioController/index');?>'"/>
<?php }
?>

<!doctype html>
<html lang="en">
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>
<body>

    <div class="container">
        <div class="areaTabelas">


            <nav class="navbar navbar-light bg-light">
                <button type="button" data-toggle="modal" data-target="#modalAddVacina" class="btn btn-outline-primary">Adicionar Vacina</button>
                <!-- BUSCA -->
                <form class="form-inline" method="get" action="<?php echo site_url('InicioController/resultadoBuscaVacinas');?>">
                    <input class="form-control mr-sm-2" name="campo_busca" type="search" placeholder="Nome da vacina" aria-label="Pesquisar"  autocomplete="off">
                    <button class="btn btn-outline-primary my-2 my-sm-0 active botaoPesquisa" type="submit" name="buscar">Pesquisar</button>
                </form>
                <!-- FIM BUSCA -->
            </nav>


       

            <table class="table" style="border: 1px solid #d0e5fb !important ">
              <thead class="thead">
                <tr>
                <th scope="col">#</th>
                <th scope="col">Nome</th>
                <th scope="col">Descrição</th>
                <th scope="col">Dose</th>
                <th scope="col">Idade</th>
                <th schope="col">Opções</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($result as $row) {?>
                <tr>
                    <th scope="row"><?php echo $row->pk_codvacina; ?></th>
                        <td><?php echo $row->nome_vacina; ?></td>
                        <td><?php echo $row->descricao_vacina; ?></td>
                        <td><?php echo $row->dose_vacina; ?></td>
                        <td><?php echo $row->idade_vacina; ?></td>
                        <td> <a href="<?php echo site_url('CrudController/editVacina');?>/<?php echo $row->pk_codvacina; ?>">Editar</a> | <a data-toggle="modal" data-target="#modalDeleteVacina<?= $row->pk_codvacina;?>" href="<?php echo site_url('CrudController/deleteVacina');?>/<?php echo $row->pk_codvacina;?>">Delete</a> </td>
                    </tr>
                    
   


        <!-- Modal Delete -->
        <div class="modal fade" id="modalDeleteVacina<?= $row->pk_codvacina;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">

                <img src="<?php echo base_url('assets/imagens/interrogacao.png')?>" style="height: 200px; width: 200px; margin: 0 auto; padding: 5%">


                <div class="modal-header">

                    <h5 class="modal-title" id="exampleModalLabel" style="margin: 0 auto;">Tem certeza que deseja deletar a vacina <?= $row->nome_vacina ?>?</h5>
                </div>
                <form method="post" action="<?php echo site_url('CrudController/deleteVacina');?>/<?php echo $row->pk_codvacina;?>">
                    <div class="modal-footer">

                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Sim, deletar</button>
                    <?php
                        echo $this->session->flashdata("erro");
                    ?>
                    </div>
                </div>
                </form>
            </div>
        </div>

<!-- FIM MODAL DELETE -->

 
   <?php } ?>

                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal Add Vacina-->
<div class="modal fade" id="modalAddVacina" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Cadastro de Vacinas</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="post" action="<?php echo site_url('CrudController/createVacina')?>">
                <div class="modal-body">        
                    <div class="form-group">
                        <label for="exampleInputnome1">Nome</label>
                        <input type="nome" required class="form-control" name="nome" id="exampleInputNome1" aria-describedby="nomeHelp" placeholder="Digite seu nome">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputdescricao1">Descrição</label>
                        <input type="text" required class="form-control" name="descricao" id="exampleInputdescricao1" aria-describedby="descricaoHelp" placeholder="Digite a descrição">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputDose1">Dose</label>
                        <input type="number" required min="0" class="form-control" name="dose" id="exampleInputDose1" placeholder="Dose">
                    </div>
                    <div class="form-group">
                    <label for="exampleInputIdade1">Idade</label>
                    <input type="text" required class="form-control" name="idade" id="exampleInputIdade1" placeholder="Idade">
                    </div><div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                        <button type="submit" class="btn btn-primary" value="save">Enviar</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

</table>
</div>
</div>
</table>
</div>
</div>

<footer class="rodape" >
    <div>
      <div class="coluna1">
        <h1 class="tituloRodape">Sobre nós</h1>
        <h4 class="textoRodape" > O sistema “vacinas online” foi criado por alunos do Instituto Federal Catarinense - Campus Araquari. Vendo a realidade atual do sistema público de saúde da cidade de Araquari na pauta de vacinações temos o objetivo de facilitar o acesso e a administração das vacinas tomadas pela população para ter um melhor controle das mesmas.
        </h4>
        <h4 class="textoRodape"> Além de facilitar o acesso a informação sobre quais vacinas devem ser tomadas conforme cada idade, e informar sobre doenças em surto, campanhas e etc com a aba de notícias. </h4>
      </div>

      

      <div class="coluna2">
        <h1 class="tituloRodape">Contato</h1>
        <h4 class="textoRodape" style="  font-weight: bold;"> Email vacinasonline.ifc@outlook.com </h4>
      </div>
    </div>
    
</footer>

<div class="rodapeFinal">
    <div style="text-align: center;">
        <h4 class="textoRodape">© Vacinas Online 2019. Criado por Gabrielle Oliveira, Gustavo Bonifácio e Jenifer Santos.</h4>
      </div>
    </div>
  </div>
</div>
</footer>

</html>

</body>
</html>
