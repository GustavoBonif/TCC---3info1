<?php
    include('cabecalho.php');
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


    <title>Sua Conta</title>
  </head>

<div class="areaCards">

      <div class="tituloConta">Minha conta</div>

    <?php  if(isset($_SESSION['user'])){ ?>

    <div class="container">

<div class="card mb-3">
  <div class="row no-gutters">
    <div class="col-md-5">
      <img src="<?php echo base_url('assets/imagens/doutor.png');?>" class="card-img" alt="..." style="border-radius: 0px; width: 70%; float: left; padding:7%" class="card-img" alt="...">
    </div>
    <div class="col-md-7">
      <div class="card-body"> 
                         <h5 class="card-title" style="line-height: 1.5; color: #39345a;"><b>Nome: </b><?php echo $_SESSION['user']['nome_user'] ?></h5>
                         <br>
                          <p class="card-text" style="font-size: 15px; line-height: 1.0; font-weight: 400; color: #7782aa;"><b>Email: </b> <?php echo $_SESSION['user']['email_user'] ?></p>

                    <?php foreach($result as $row) { 
                      if($row->fk_coduser == $_SESSION['user']['pk_coduser']){?>
                          <p class="card-text" style="font-size: 15px; line-height: 1.0; font-weight: 400; color: #7782aa;"><b>Local de Trabalho: </b><?php echo $row->localtrab_userfunc ?></p>

                          <p class="card-text" style="margin-top: 7%"><a href="<?php echo site_url('CrudController/edit');?>/<?php echo $_SESSION['user']['pk_coduser'];?>"  style="font-size: 15px; opacity: 1;">Editar informações pessoais</a></p>

                            <p class="card-text" ><a href="<?php echo site_url('CrudController/listaVacina');?>"  style="font-size: 15px; opacity: 1;">Lista de Vacina</a></p>

                    <?php   }
                          } 
                    ?>
                     


                          <?php
                            }elseif (empty($_SESSION['user'])) { ?>
                                <p>Você não deveria estar aqui</p>
                            <?php 
                              }
                            ?>


                        </div>
                      </div>
                    </div>
                  </div>
                </a>
            </div> 
      </div>
    </div>
  </div>
</div>

<footer class="rodape">
    <div>
      <div class="coluna1">
        <h1 class="tituloRodape">Sobre nós</h1>
        <h4 class="textoRodape" > O sistema “vacinas online” foi criado por alunos do Instituto Federal Catarinense - Campus Araquari. Vendo a realidade atual do sistema público de saúde da cidade de Araquari na pauta de vacinações temos o objetivo de facilitar o acesso e a administração das vacinas tomadas pela população para ter um melhor controle das mesmas.
        </h4>
        <h4 class="textoRodape"> Além de facilitar o acesso a informação sobre quais vacinas devem ser tomadas conforme cada idade, e informar sobre doenças em surto, campanhas e etc com a aba de notícias. </h4>
      </div>

      

      <div class="coluna2">
        <h1 class="tituloRodape">Contato</h1>
        <h4 class="textoRodape" style="  font-weight: bold;"> Email vacinasonline.ifc@outlook.com </h4>
      </div>
    </div>
    
</footer>

<div class="rodapeFinal">
    <div style="text-align: center;">
        <h4 class="textoRodape">© Vacinas Online 2019. Criado por Gabrielle Oliveira, Gustavo Bonifácio e Jenifer Santos.</h4>
      </div>
    </div>
  </div>
</div>
</footer>

</html>
