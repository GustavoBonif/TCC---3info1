<?php
    include('cabecalho.php');

?>
<!doctype html>

  <body>
    <br>
    <div class="container">
        <div class="areaTabelas">
<?php if($row->fk_codtipuser == 1){ ?>
        <form method="post" action="<?php echo site_url('CrudController/updateDataComum')?>/<?php echo $row->pk_coduser; ?>"> 
<?php }elseif($row->fk_codtipuser == 2){ ?>

        <form method="post" action="<?php echo site_url('CrudController/updateDataFunc')?>/<?php echo $row->pk_coduser; ?>">

<?php }elseif($row->fk_codtipuser == 3){ ?>
        <form method="post" action="<?php echo site_url('CrudController/updateDataAdm')?>/<?php echo $row->pk_coduser; ?>">
<?php } ?>

            <div class="form-group">
                <label for="exampleInputNome1">Nome</label>
                <input type="nome" class="form-control" name="nome" value="<?php echo $row->nome_user;?>" id="exampleInputNome1" aria-describedby="nomeHelp" placeholder="Digite seu nome">
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Email</label>
                <input type="email" class="form-control" name="email" value="<?php echo $row->email_user;?>" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Digite seu email">
            </div>
            <div class="form-group">
                <label for="exampleInputSenha1">Senha</label>
                <input type="password" class="form-control" name="senha" id="senha" value="<?php echo $row->senha_user;?>" id="exampleInputSenha1" placeholder="Senha">
            </div>
            <div class="form-group">
                    <label for="exampleInputSenha1">Confirme a Senha</label>
                    <input type="password" class="form-control"  id="confirmaSenha" placeholder="Senha" value="<?php echo $row->senha_user;?>">
                </div>

<?php
     if($row->fk_codtipuser == 1){
?>
            <div class="form-group">
                <label for="exampleInputCpf1">CPF</label>
                <input type="text" class="form-control"  maxlength="11" name="cpf" value="<?php echo $comum->pk_cpf_usercomum;?>" id="exampleInputCpf1" placeholder="CPF">
            </div>

            <div class="form-group">
                <label for="exampleInputRG1">RG</label>
                <input type="text" class="form-control"  maxlength="7" name="rg" value="<?php echo $comum->rg_usercomum;?>" id="exampleInputRg1" placeholder="RG">
            </div>

<?php
     }     if ($row->fk_codtipuser == 1) { ?>
        <div class="form-group form-radio">
            <input hidden type="radio" class="form-radio-input" checked value="1" name="codtipuser" id="exampleRadio1">

        </div>

<?php       
        }elseif ($row->fk_codtipuser == 2) { 
            if($row->pk_coduser == $func->fk_coduser){?>

            <div class="form-group">
                <label for="exampleInputCpf1">CPF</label>
                <input type="text" class="form-control"  maxlength="11" name="cpf" value="<?php echo $func->cpf_userfunc;?>" id="exampleInputCpf1" placeholder="CPF">
            </div>



        <div class="form-group">
        <label for="exampleInputPosto1">Posto de Saúde</label>
        <br>
                <select name="localtrab">
                    <option value="<?= $func->localtrab_userfunc?>">Atual: <?= $func->localtrab_userfunc?></option>
                    <option value="Posto de Saúde de Araquari">Posto de Saúde de Araquari</option>
                    <option value="Posto de Saúde Itinga">Posto de Saúde Itinga</option>
                </select>
            </div>

        <div class="form-group form-radio">
            <input hidden type="radio" class="form-radio-input" checked value="2" name="codtipuser" id="exampleRadio1">

        </div>
<?php
         }
     }elseif ($row->fk_codtipuser == 3) { ?>

        <div class="form-group form-radio">
            <input hidden type="radio" class="form-radio-input" checked value="3" name="codtipuser" id="exampleRadio1">

        </div>
<?php
     }

?>

            </div>
            <div class="modal-footer" style="margin-bottom: 5%">
                <a href="<?php echo site_url('InicioController/contaViewAdm');?>">
                    <button type="button" class="btn btn-secondary">
                    Fechar</button>
                </a>
                <button type="submit" class="btn btn-primary" value="save">Enviar</button>
            </div>
        </form>
    </div>
</form>
</form>
</div>
  </body>
<footer class="rodape">
    <div>
      <div class="coluna1">
        <h1 class="tituloRodape">Sobre nós</h1>
        <h4 class="textoRodape" > O sistema “vacinas online” foi criado por alunos do Instituto Federal Catarinense - Campus Araquari. Vendo a realidade atual do sistema público de saúde da cidade de Araquari na pauta de vacinações temos o objetivo de facilitar o acesso e a administração das vacinas tomadas pela população para ter um melhor controle das mesmas.
        </h4>
        <h4 class="textoRodape"> Além de facilitar o acesso a informação sobre quais vacinas devem ser tomadas conforme cada idade, e informar sobre doenças em surto, campanhas e etc com a aba de notícias. </h4>
      </div>

      

      <div class="coluna2">
        <h1 class="tituloRodape">Contato</h1>
        <h4 class="textoRodape" style="  font-weight: bold;"> Email vacinasonline.ifc@outlook.com </h4>
      </div>
    </div>
    
</footer>

<div class="rodapeFinal">
    <div style="text-align: center;">
        <h4 class="textoRodape">© Vacinas Online 2019. Criado por Gabrielle Oliveira, Gustavo Bonifácio e Jenifer Santos.</h4>
      </div>
    </div>
  </div>
</div>
</footer>

<script type="text/javascript">
    
    var password = document.getElementById("senha")
    , confirm_password = document.getElementById("confirmaSenha");

    function validatePassword(){
    if(password.value != confirm_password.value) {
        confirm_password.setCustomValidity("As senhas estão diferentes");
    } else {
        confirm_password.setCustomValidity('');
    }
    }

    password.onchange = validatePassword;
    confirm_password.onkeyup = validatePassword;

</script>

<script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.mask.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-3.3.1.min.js"></script>

</html>
