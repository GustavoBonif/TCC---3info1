<?php
    include('cabecalho.php');

?>
<!doctype html>

  <body>

    
    <br>
    <div class="container">
                <div class="areaTabelas">

        <form method="post" action="<?php echo site_url('CrudController/updateDataVacina')?>/<?= $row['pk_codvacina']; ?>">

            <div class="form-group">
                <label for="exampleInputNome1">Nome</label>
                <input type="nome" class="form-control" name="nome" value="<?php echo $row['nome_vacina'];?>" id="exampleInputNome1" aria-describedby="nomeHelp" placeholder="Digite seu nome">
            </div>
            <div class="form-group">
                <label for="exampleInputDescricao1">Descrição</label>
                <input type="text" class="form-control" name="descricao" value="<?php echo $row['descricao_vacina'];?>" id="exampleInputDescricao1" aria-describedby="emailHelp" placeholder="Digite a descrição">
            </div>
            <div class="form-group">
                <label for="exampleInputDose1">Dose</label>
                <input type="number" class="form-control" name="dose" value="<?php echo $row['dose_vacina'];?>" id="exampleInputDose1" placeholder="Dose">
            </div>
            <div class="form-group">
                <label for="exampleInputIdade1">Idade</label>
                <input type="text" class="form-control" name="idade" value="<?php echo $row['idade_vacina'];?>" id="exampleInputIdade1" placeholder="Idade">
            </div>

            </div>
            <div class="modal-footer" style="margin-bottom: 5%">
                <a href="<?php echo site_url('InicioController/listaVacina');?>">
                    <button type="button" class="btn btn-secondary">
                    Fechar</button>
                </a>
                <button type="submit" class="btn btn-primary" value="save">Enviar</button>
            </div>
        </form>
    </div>

  </body>
<footer class="rodape">
    <div>
      <div class="coluna1">
        <h1 class="tituloRodape">Sobre nós</h1>
        <h4 class="textoRodape" > O sistema “vacinas online” foi criado por alunos do Instituto Federal Catarinense - Campus Araquari. Vendo a realidade atual do sistema público de saúde da cidade de Araquari na pauta de vacinações temos o objetivo de facilitar o acesso e a administração das vacinas tomadas pela população para ter um melhor controle das mesmas.
        </h4>
        <h4 class="textoRodape"> Além de facilitar o acesso a informação sobre quais vacinas devem ser tomadas conforme cada idade, e informar sobre doenças em surto, campanhas e etc com a aba de notícias. </h4>
      </div>

      

      <div class="coluna2">
        <h1 class="tituloRodape">Contato</h1>
        <h4 class="textoRodape" style="  font-weight: bold;"> Email vacinasonline.ifc@outlook.com </h4>
      </div>
    </div>
    
</footer>

<div class="rodapeFinal">
    <div style="text-align: center;">
        <h4 class="textoRodape">© Vacinas Online 2019. Criado por Gabrielle Oliveira, Gustavo Bonifácio e Jenifer Santos.</h4>
      </div>
    </div>
  </div>
</div>
</footer>

</html>


</html>