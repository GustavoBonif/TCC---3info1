    <?php
    include('cabecalho.php');


    if ($_SESSION['user']['fk_codtipuser'] != 3) { ?>
        <meta http-equiv="refresh" content="0; URL='<?php echo site_url('InicioController/index');?>'"/>
<?php }

    ?>

    <!doctype html>
    <html lang="en">
    <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    </head>
    <body>

        <!-- LISTA fUNCIONÁRIO -->
        <div class="container">
            <div class="areaTabelas">

    

        <!-- BUSCA FUNCIONARIOS -->

        <nav class="navbar navbar-light bg-light">
            <a class="navbar-brand">Usuário Funcionário</a>
       <!-- INICIO SE O USUARIO FOR ADM -->
      <?php
                if(isset($_SESSION['user'])){
                    if($_SESSION['user']['fk_codtipuser'] == 3){ ?>
                        <button type="button" data-toggle="modal" data-target="#modalAddFunc" class="btn btn-outline-primary">Adicionar Funcionário</button>
                    <br>
                    <br>
                <?php
                }
            }
            ?>

            <form class="form-inline" method="get" action="<?php echo site_url('InicioController/resultadoControleBuscaFunc');?>">
                <input class="form-control mr-sm-2" name="campo_busca" type="search" placeholder="Nome do funcionário" aria-label="Pesquisar"  autocomplete="off">
                <button class="btn btn-outline-primary my-2 my-sm-0 active botaoPesquisa" type="submit" name="buscar">Pesquisar</button>
            </form>
        </nav>


        <!-- FIM BUSCA -->
        

            
    <!-- Modal Add Func -->
    <div class="modal fade" id="modalAddFunc" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Cadastro de Funcionário</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" action="<?php echo site_url('CrudController/createFunc')?>">
                    <div class="modal-body">        
                        <div class="form-group">
                            <label for="exampleInputnome1">Nome</label>
                            <input type="nome" required class="form-control" name="nome" id="exampleInputNome1" aria-describedby="nomeHelp" placeholder="Digite seu nome">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Email</label>
                            <input type="email" required class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Digite seu email">
                        </div>
                        <div class="form-group">
                            <label for="senha">Senha</label>
                            <input type="password" required class="form-control" name="senha" id="senha" placeholder="Senha">
                        </div>
                        <div class="form-group">
                            <label for="senha">Confirme a Senha</label>
                            <input type="password" required class="form-control"  id="confirmaSenha" placeholder="Senha">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputCPF1">CPF</label>
                            <input type="int" required maxlength="11" class="form-control" name="cpf" id="exampleInputCPF1" placeholder="CPF">
                        </div>
                        <p>Local de Trabalho</p>
                        <div>
                            <select name="localtrab">
                                <option value="Posto de Saúde de Araquari">Posto de Saúde de Araquari</option>
                                <option value="Posto de Saúde Itinga">Posto de Saúde Itinga</option>
                            </select>
                        </div>
                        <br>
                        
                        <div class="form-group form-radio">
                            <input type="hidden" class="form-radio-input" checked value="2" name="codtipuser" id="exampleRadio1"> <!-- codigo que define como tipo funcionario -->
                            
                        </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                            <button type="submit" class="btn btn-primary" value="save">Enviar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    


        <!-- FIM Modal Add Func -->
      <table class="table" style="border: 1px solid #d0e5fb !important ">
            <thead class="thead">
                <tr>
                <th scope="col">#</th>
                <th scope="col">Nome</th>
                <th scope="col">Email</th> 
                <th scope="col">CPF</th>
                <th schope="col">Posto</th>               
                <th schope="col">Opções</th>
                
                </tr>
            </thead>
            <tbody>
                    <?php 
                         
                        foreach($todos as $row) {
                            foreach($func as $dados){ 
                                if($dados->fk_coduser == $row->pk_coduser){
                                  
                                    $id_user = $row->pk_coduser;
                                    ?>
                    <tr>
                    <th scope="row"><?php echo $row->pk_coduser; ?></th>
                    <td><?php echo $row->nome_user; ?></td>
                    <td><?php echo $row->email_user; ?></td>
                    <td><?php echo $dados->cpf_userfunc; ?></td>
                    <td><?php echo $dados->localtrab_userfunc; ?></td>

                    
                    <!-- <td> <a href="<?php echo site_url('CrudController/edit');?>/<?php echo $row->pk_coduser;?>">Editar</a> | -->
                    
                    <td>
                        <a data-toggle="modal" data-target="#modalDeleteUserFunc<?= $row->pk_coduser ?>" href="#">Delete</a>
                    </td>
                    
                    </tr>

                    <?php
                     
                    ?>


                <!-- Modal Delete -->
                <div class="modal fade" id="modalDeleteUserFunc<?= $row->pk_coduser ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Tem certeza que deseja deletar o funcionário <?= $row->nome_user ?> ?</h5>
                            </div>
                            <form method="post" action="<?php echo site_url('CrudController/deleteFunc');?>/<?php echo $row->pk_coduser;?>">
                                <div class="modal-footer">
                                    
                                    
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                    <button type="submit" class="btn btn-primary">Sim, deletar</button>
                                    <?php
                                        echo $this->session->flashdata("erro");
                                    ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

    <!-- FIM MODAL DELETE -->

                    <?php 
                    
                            }
                        }
                    }
                        
                    ?>
            </tbody>
        </table>  
    </div>

     <!-- FIM LISTA FUNCIONÁRIO -->



    <!-- LISTA COMUM -->

    <div class="container">
        <div class="areaTabelas">

        <!-- BUSCA COMUM -->
       <nav class="navbar navbar-light bg-light">
      <a class="navbar-brand">Usuário Comum</a>
      <form class="form-inline" method="get" action="<?php echo site_url('InicioController/resultadoControleBuscaComum');?>">
             <input class="form-control mr-sm-2" name="campo_busca" type="search" placeholder="Nome do usuário" aria-label="Pesquisar"  autocomplete="off">
        <button class="btn btn-outline-success my-2 my-sm-0 active botaoPesquisa" type="submit">Pesquisar</button>
      </form>
    </nav>
        <!-- FIM BUSCA -->

       <table class="table" style="border: 1px solid #d0e5fb !important ">
            <thead class="thead">
                <tr>
                <th scope="col">#</th>
                <th scope="col">Nome</th>
                <th scope="col">Email</th>
                <th scope="col">CPF</th>                 
                <th schope="col">Opções</th>
                
                </tr>
            </thead>
            <tbody>
                <?php foreach($todos as $row) {
                        foreach($comum as $user_comum){
                            if($row->fk_codtipuser == 1 and ($user_comum->fk_coduser == $row->pk_coduser)){?>
                <tr>
                    <th scope="row"><?php echo $row->pk_coduser; ?></th>
                    <td><?php echo $row->nome_user; ?></td>
                    <td><?php echo $row->email_user; ?></td>
                    <td><?php echo $user_comum->pk_cpf_usercomum; ?></td>
                    
                    <!-- <td> <a href="<?php echo site_url('CrudController/edit');?>/<?php echo $row->pk_coduser;?>">Editar</a> |  -->
                    
                    <td>
                        <a data-toggle="modal" data-target="#modalDeleteUserComum<?= $row->pk_coduser ?>" href="#">Delete</a> 
                    </td>
                </tr>

</tbody>


        <!-- Modal Delete -->
        <div class="modal fade" id="modalDeleteUserComum<?= $row->pk_coduser ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Tem certeza que deseja deletar o usuário <?= $row->nome_user ?> ?</h5>
                    </div>
                    <form method="post" action="<?php echo site_url('CrudController/deleteComum');?>/<?php echo $row->pk_coduser;?>">
                        <div class="modal-footer">
                        
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Sim, deletar</button>
                        <?php
                            echo $this->session->flashdata("erro");
                        ?>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
</div>
    <!-- FIM MODAL DELETE -->

                <?php       }
                        }
                    } 
                ?>


                
            </tbody>

            </table> </div>
</div>
        </div>

        
            <!-- FIM LISTA COMUM -->

    </body>

   <footer class="rodape">
    <div>
      <div class="coluna1">
        <h1 class="tituloRodape">Sobre nós</h1>
        <h4 class="textoRodape" > O sistema “vacinas online” foi criado por alunos do Instituto Federal Catarinense - Campus Araquari. Vendo a realidade atual do sistema público de saúde da cidade de Araquari na pauta de vacinações temos o objetivo de facilitar o acesso e a administração das vacinas tomadas pela população para ter um melhor controle das mesmas.
        </h4>
        <h4 class="textoRodape"> Além de facilitar o acesso a informação sobre quais vacinas devem ser tomadas conforme cada idade, e informar sobre doenças em surto, campanhas e etc com a aba de notícias. </h4>
      </div>

      

      <div class="coluna2">
        <h1 class="tituloRodape">Contato</h1>
        <h4 class="textoRodape" style="  font-weight: bold;"> Email vacinasonline.ifc@outlook.com </h4>
      </div>
    </div>
    
</footer>

<div class="rodapeFinal">
    <div style="text-align: center;">
        <h4 class="textoRodape">© Vacinas Online 2019. Criado por Gabrielle Oliveira, Gustavo Bonifácio e Jenifer Santos.</h4>
      </div>
    </div>
  </div>
</div>
</footer>


<script type="text/javascript">

var password = document.getElementById("senha")
, confirm_password = document.getElementById("confirmaSenha");

function validatePassword(){
if(password.value != confirm_password.value) {
    confirm_password.setCustomValidity("As senhas estão diferentes");
} else {
    confirm_password.setCustomValidity('');
}
}

password.onchange = validatePassword;
confirm_password.onkeyup = validatePassword;

</script>

<script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.mask.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-3.3.1.min.js"></script>


</html>


