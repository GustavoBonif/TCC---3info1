<?php

include ('cabecalho.php');

?>


<div class="hero-wrap" style="background-image: url(<?php echo base_url('assets/imagens/bg_1.jpg');?>); background-attachment:fixed;">




      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center" data-scrollax-parent="true">
          <div class="col-md-8 ftco-animate text-center">
            <h1 class="mb-4">Vacinas Online</h1>
            <p>Carteira de Vacinação Online da Cidade de Araquari</p>
          </div>
        </div>
      </div>
    </div>

<div class="departamentos" >
    <div class="row" >  
      <div class="col-3 fundoMenuVertical" >
        <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical" >

          <a class="nav-link active itensMenuVertical" id="v-pills-prematuro-tab" data-toggle="pill" href="#v-pills-prematuro" role="tab" aria-controls="v-pills-prematuro" aria-selected="true" style="margin-top: 15%">Prematuro</a>

          <a class="nav-link itensMenuVertical" id="v-pills-crianca-tab" data-toggle="pill" href="#v-pills-crianca" role="tab" aria-controls="v-pills-crianca" aria-selected="false" style="margin-top: 3%">Criança</a>

          <a class="nav-link itensMenuVertical" id="v-pills-adolescente-tab" data-toggle="pill" href="#v-pills-adolescente" role="tab" aria-controls="v-pills-adolescente" aria-selected="false" style="margin-top: 3%">Adolescente</a>

          <a class="nav-link itensMenuVertical" id="v-pills-adulto-tab" data-toggle="pill" href="#v-pills-adulto" role="tab" aria-controls="v-pills-adulto" aria-selected="false" style="margin-top: 3%">Adulto</a>

          <a class="nav-link itensMenuVertical" id="v-pills-idoso-tab" data-toggle="pill" href="#v-pills-idoso" role="tab" aria-controls="v-pills-idoso" aria-selected="false" style="margin-top: 3%">Idoso</a>

          <a class="nav-link itensMenuVertical" id="v-pills-gestante-tab" data-toggle="pill" href="#v-pills-gestante" role="tab" aria-controls="v-pills-gestante" aria-selected="false" style="margin-top: 3%">Gestante</a>


        </div>
      </div>
      <div class="col-9" style="padding: 5%;">
        <div class="tab-content" id="v-pills-tabContent">
          <div class="tab-pane fade show active" id="v-pills-prematuro" role="tabpanel" aria-labelledby="v-pills-prematuro-tab">
                <div class="jumbotron" style="background-color: white">
                  <img src="<?php echo base_url('assets/imagens/iconeprematuro.png')?>" class="icones">
                  <h1 class="display-4 tituloDepartamento">Prematuro</h1>
                  <p class="lead text1Departamento">Seu filho deverá receber todas as vacinas como todas as crianças nascidas a termo. O seu bebê fará um calendário especial durante um período de sua vida e depois seguirá o calendário normal conforme a data de nascimento. (Confira o calendário da criança e o calendário do adolescente)</p>
                  <hr class="my-4">
                  <p class="text1Departamento">Vacinas obrigatorias: coqueluche, influenza, varicela, sarampo, caxumba e rubéola.</p>
                  
                </div>              
          </div>
          <div class="tab-pane fade" id="v-pills-crianca" role="tabpanel" aria-labelledby="v-pills-crianca-tab">
                <div class="jumbotron" style="background-color: white;">
                  <img src="<?php echo base_url('assets/imagens/iconecrianca.png')?>" class="icones">
                  <h1 class="display-4 tituloDepartamento">Crianças</h1>
                  <p class="lead text1Departamento">Crianças de 0 a 10 anos, para definir vacinas e esquemas de doses, considerar a orientação do médico assistente que irá atualizar o calendário vacinal a ser seguido. O calendário vacinal é uma seqüência cronológica de vacinas que se administram sistematicamente às crianças de determinada área ou região.
No calendário vacinal proposto pelo Ministério da Saúde incluem as seguintes vacinas:</p>
                  <hr class="my-4">
                  <p class="text1Departamento">Vacinas obrigatórias: BCG, Pentavalente, Meningocócica C, VIP, Pneumocócica 10 Valente, Rotavírus, Tríplice viral, DTP, VOP, Hepatite A, Tetra viral, Varicela atenuada, Hepatite B, Febre amarela.</p>
                  
                </div>   
          </div>
          <div class="tab-pane fade" id="v-pills-adolescente" role="tabpanel" aria-labelledby="v-pills-adolescente-tab">
                <div class="jumbotron" style="background-color: white">
                  <img src="<?php echo base_url('assets/imagens/iconeadolescente.png')?>" class="icones">
                  <h1 class="display-4 tituloDepartamento">Adolescente</h1>
                  <p class="lead text1Departamento">Adolescentes de 10 a 19 anos, as mudanças que ocorrem na adolescência concentram-se, sobretudo, na conscientização e expressão da sexualidade e da individualidade. Há necessidade de orientação médica em relação à saúde reprodutiva e doenças imunopreveníveis. Na infância as crianças são vistas periodicamente pelos pediatras, mas apesar dos riscos de algumas patologias na adolescência, elas consultam menos os médicos que outros grupos etários. É fundamental manter cuidados básicos de saúde e imunização adequada para evitar problemas futuros. Campanhas nacionais de imunização são necessárias para atualizar o calendário de vacinas dos adolescentes.</p>
                  <hr class="my-4">
                  <p class="text1Departamento">Vacinas obrigatórias: Tríplice viral, Hepatites A, B e A + B, HPV, dTpa ou dTpa-IPV, Varicela, Meningite meningocócica conjugada, Meningite meningocócica tipo B, Febre amarela.</p>
                  
                </div>   
          </div>
          <div class="tab-pane fade" id="v-pills-adulto" role="tabpanel" aria-labelledby="v-pills-adulto-tab">
                <div class="jumbotron" style="background-color: white">
                  <img src="<?php echo base_url('assets/imagens/iconeadulto.png')?>" class="icones">
                  <h1 class="display-4 tituloDepartamento">Adultos</h1>
                  <p class="lead text1Departamento">Você está com a sua caderneta de vacinação em dia? Muita gente não sabe, mas os adultos também precisam ser imunizados. Quem está com as vacinas desatualizadas coloca em risco não apenas a própria saúde, mas também pode se tornar um transmissor de doenças, em especial para as crianças e idosos, que são grupos mais vulneráveis. Saiba quais vacinas devem ser tomadas na fase adulta. Segundo o Ministério da Saúde, a partir dos 20 anos você precisa se vacinar ao menos contra sarampo, caxumba, rubéola, hepatite B, febre amarela, difteria e tétano. Para se proteger de todas essas doenças, são quatro tipos de vacinas, disponíveis pelo Sistema Único de Saúde (SUS):</p>
                  <hr class="my-4">
                  <p class="text1Departamento">Vacinas obrigatórias: Dupla adulto, Febre amarela, Dupla viral, Influenza</p>
                  
                </div>  
              </div>

          <div class="tab-pane fade" id="v-pills-idoso" role="tabpanel" aria-labelledby="v-pills-idoso-tab">
                <div class="jumbotron" style="background-color: white">
                  <img src="<?php echo base_url('assets/imagens/iconeidoso.png')?>" class="icones">
                  <h1 class="display-4 tituloDepartamento">Idosos</h1>
                  <p class="lead text1Departamento">Idosos se enquadram em um grupo de risco para determinadas doenças, que podem causas complicações graves à saúde. Além das comuns aos adultos, é importante que pessoas acima de 60 anos tomem algumas vacinas.</p>
                  <hr class="my-4">
                  <p class="text1Departamento">Vacinas obrigatórias: Influenza, pneumocócica, Febre amarela,  Meningocócica, herpes zóster,</p>
                  
                </div> 
              </div>

          <div class="tab-pane fade" id="v-pills-gestante" role="tabpanel" aria-labelledby="v-pills-gestante-tab">
                <div class="jumbotron" style="background-color: white">
                  <img src="<?php echo base_url('assets/imagens/iconegestante.png')?>" class="icones">
                  <h1 class="display-4 tituloDepartamento">Gestante</h1>
                  <p class="lead text1Departamento">Logo após a confirmação da gravidez, a mulher inicia o pré-natal. Nele, são passadas diversas recomendações pelo médico à futura mamãe, uma delas é a atualização da caderneta de vacinação, com a aplicação de três vacinas recomendadas pelo Ministério da Saúde, conforme o histórico da gestante.</p>
                  <hr class="my-4">
                  <p class="text1Departamento">Vacinas obrigatórias: Dupla adulto, Hepatite B, Influenza</p>
                  
                </div> 
              </div>



        </div>
      </div>
    </div>
  </div>




<footer class="rodape">
    <div>
      <div class="coluna1">
        <h1 class="tituloRodape">Sobre nós</h1>
        <h4 class="textoRodape" > O sistema “vacinas online” foi criado por alunos do Instituto Federal Catarinense - Campus Araquari. Vendo a realidade atual do sistema público de saúde da cidade de Araquari na pauta de vacinações temos o objetivo de facilitar o acesso e a administração das vacinas tomadas pela população para ter um melhor controle das mesmas.
        </h4>
        <h4 class="textoRodape"> Além de facilitar o acesso a informação sobre quais vacinas devem ser tomadas conforme cada idade, e informar sobre doenças em surto, campanhas e etc com a aba de notícias. </h4>
      </div>

      

      <div class="coluna2">
        <h1 class="tituloRodape">Contato</h1>
        <h4 class="textoRodape" style="  font-weight: bold;"> Email vacinasonline.ifc@outlook.com </h4>
      </div>
    </div>
    
</footer>

<div class="rodapeFinal">
    <div style="text-align: center;">
        <h4 class="textoRodape">© Vacinas Online 2019. Criado por Gabrielle Oliveira, Gustavo Bonifácio e Jenifer Santos.</h4>
      </div>
    </div>
  </div>
</div>
</footer>

</html>
