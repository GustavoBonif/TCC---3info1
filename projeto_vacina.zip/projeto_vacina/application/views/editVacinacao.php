<?php
    include('cabecalho.php');

?>
<!doctype html>

  <body>

    
    <br>        <div class="areaCards">

    <div class="container">
        <form method="post" action="<?php echo site_url('CrudController/updateDataVacinacao')?>/<?= $vacinacao['pk_codvacinacao']; ?>">
			
			<div>	


                    <p>Selecione da Vacina:</p>
                    <select name="codvacina">
                        <!-- <option value="" selected disabled hidden >Selecione a Vacina</option> -->
                        
                    
                        
    <?php

                        foreach ($vacinas as $data) {
                            foreach ($vacinacoes as $row) {
                                if ($row->fk_codvacina == $data->pk_codvacina and ($vacinacao['fk_codvacina'] == $data->pk_codvacina) and ($vacinacao['pk_codvacinacao'] == $row->pk_codvacinacao)) { ?>

                                    <option selected value="<?= $row->fk_codvacina?>">Atual: <?= $data->nome_vacina?></option>
                                    
                        <?php    
                                }
                            }
    ?>
                        <option value="<?php echo $data->pk_codvacina ?>"><?php echo $data->nome_vacina; ?></option>                                      
    <?php
                        }
    ?>
            
                    </select>
                </div>
<?php

foreach ($vacinas as $data) {
    foreach ($vacinacoes as $row) {
        if ($row->fk_codvacina == $data->pk_codvacina and ($vacinacao['fk_codvacina'] == $data->pk_codvacina) and ($vacinacao['pk_codvacinacao'] == $row->pk_codvacinacao)) { ?>

                

            <div class="form-group">
                <input type="hidden" class="form-control" name="dose" value="<?php echo $vacinacao['dose_vacinacao'];?>" id="exampleInputDose1" placeholder="Dose">
            </div>

<?php
        }
    }
}

?>
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Editar Vacinação</h5>
            </div>

            <div class="form-group">
                <label for="exampleInputData1">Data</label>
                <input type="date" class="form-control" name="data" value="<?php echo $vacinacao['data_vacinacao'];?>" id="exampleInputData1" placeholder="Data">
            </div>

            <input type="hidden" class="form-control" name="cpf" value="<?php echo $vacinacao['fk_cpf'];?>" id="exampleInputCPF1">

            <input type="hidden" class="form-control" name="codfunc" value="<?php echo $vacinacao['fk_codfunc'];?>" id="exampleInputCodFunc1">

            </div>
            <div class="modal-footer">
                <a href="<?php echo site_url('InicioController/controleCarteira');?>">
                    <button type="button" class="btn btn-secondary">
                    Fechar</button>
                </a>
                <button type="submit" class="btn btn-primary" value="save">Enviar</button>
            </div>
        </form>
    </div>
</div>

  </body>
<footer class="rodape">
    <div>
      <div class="coluna1">
        <h1 class="tituloRodape">Sobre nós</h1>
        <h4 class="textoRodape" > O sistema “vacinas online” foi criado por alunos do Instituto Federal Catarinense - Campus Araquari. Vendo a realidade atual do sistema público de saúde da cidade de Araquari na pauta de vacinações temos o objetivo de facilitar o acesso e a administração das vacinas tomadas pela população para ter um melhor controle das mesmas.
        </h4>
        <h4 class="textoRodape"> Além de facilitar o acesso a informação sobre quais vacinas devem ser tomadas conforme cada idade, e informar sobre doenças em surto, campanhas e etc com a aba de notícias. </h4>
      </div>

      

      <div class="coluna2">
        <h1 class="tituloRodape">Contato</h1>
        <h4 class="textoRodape" style="  font-weight: bold;"> Email vacinasonline.ifc@outlook.com </h4>
      </div>
    </div>
    
</footer>

<div class="rodapeFinal">
    <div style="text-align: center;">
        <h4 class="textoRodape">© Vacinas Online 2019. Criado por Gabrielle Oliveira, Gustavo Bonifácio e Jenifer Santos.</h4>
      </div>
    </div>
  </div>
</div>
</footer>

</html>

</html>