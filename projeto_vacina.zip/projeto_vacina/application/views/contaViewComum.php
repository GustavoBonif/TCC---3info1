<?php
    include('cabecalho.php');
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


    <title>Sua Conta</title>
  </head>

  <div class="areaCards">

      <div class="tituloConta">Minha conta</div>

<div class="fundo">
  
<?php  if(isset($_SESSION['user'])){ ?>


<div class="container">

<div class="card mb-3">
  <div class="row no-gutters">
    <div class="col-md-5">
      <img src="<?php echo base_url('assets/imagens/comum.png');?>" class="card-img" alt="..." style="border-radius: 0px; width: 80%; float: left;" class="card-img" alt="...">
    </div>
    <div class="col-md-7">
      <div class="card-body"> 
        <h5 class="card-title" style="line-height: 1.5; color: #39345a;"><p>Nome: <?php echo $_SESSION['user']['nome_user'] ?></p></h5>
        <p class="card-text" style="font-size: 15px; line-height: 1.0; font-weight: 400; color: #7782aa;">Email: <?php echo $_SESSION['user']['email_user'] ?></p>
          <?php foreach($result as $row) { 
            if($row->fk_coduser == $_SESSION['user']['pk_coduser']){?>

                <p class="card-text" style="font-size: 15px; line-height: 1.0; font-weight: 400; color: #7782aa;">CPF: <?php echo $row->pk_cpf_usercomum ?></p>
                <p class="card-text" style="font-size: 15px; line-height: 1.0; font-weight: 400; color: #7782aa;">RG: <?php echo $row->rg_usercomum ?></p>


  <?php   }
        } 
  ?>
      

      <br>  
      <div>
         <p class="card-text" style="font-size: 15px; line-height: 1.0; font-weight: 400; color: #7782aa;">Opções</p>

          <td> 
            <p class="card-text" style="margin-top: 7%">
            <a href="<?php echo site_url('CrudController/edit');?>/<?php echo $_SESSION['user']['pk_coduser'];?>" style="font-size: 15px; opacity: 1;">Editar</a></p>
             
              <p class="card-text">
              <a data-toggle="modal" data-target="#modalDeleteContaComum" href="<?php echo site_url('CrudController/deleteComum');?>/<?php echo $_SESSION['user']['pk_coduser'];?>" style="font-size: 15px; opacity: 1;">Delete</a></p>
            </td>
      </div>
    </div>


      </div>
    </div>
  </div>
</div>





                
<!-- Modal Delete -->
<div class="modal fade" id="modalDeleteContaComum" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                      <div class="modal-content">
                          <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel">Tem certeza que deseja deletar a sua conta?</h5>
                          </div>
                          <!--<img src="1.jpg">-->
                          <form method="post" action="<?php echo site_url('CrudController/deleteContaComum');?>/<?php echo $_SESSION['user']['pk_coduser'];?>">
                              <div class="modal-footer">

                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                              <button type="submit" class="btn btn-primary">Sim, deletar</button>
                              <?php
                                  echo $this->session->flashdata("erro");
                              ?>
                              </div>
                          </div>
                          </form>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </a></div>
      </div>
    </div>
  </div>
  </div>
  

<!-- FIM MODAL DELETE -->
<?php
  }
?>
  </body>
<footer class="rodape">
    <div>
      <div class="coluna1">
        <h1 class="tituloRodape">Sobre nós</h1>
        <h4 class="textoRodape" > O sistema “vacinas online” foi criado por alunos do Instituto Federal Catarinense - Campus Araquari. Vendo a realidade atual do sistema público de saúde da cidade de Araquari na pauta de vacinações temos o objetivo de facilitar o acesso e a administração das vacinas tomadas pela população para ter um melhor controle das mesmas.
        </h4>
        <h4 class="textoRodape"> Além de facilitar o acesso a informação sobre quais vacinas devem ser tomadas conforme cada idade, e informar sobre doenças em surto, campanhas e etc com a aba de notícias. </h4>
      </div>

      

      <div class="coluna2">
        <h1 class="tituloRodape">Contato</h1>
        <h4 class="textoRodape" style="  font-weight: bold;"> Email vacinasonline.ifc@outlook.com </h4>
      </div>
    </div>
    
</footer>

<div class="rodapeFinal">
    <div style="text-align: center;">
        <h4 class="textoRodape">© Vacinas Online 2019. Criado por Gabrielle Oliveira, Gustavo Bonifácio e Jenifer Santos.</h4>
      </div>
    </div>
  </div>
</div>
</footer>

</html>

</html>