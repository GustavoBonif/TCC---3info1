<?php
    include('cabecalho.php');

?>
<!doctype html>

  <body>

    
    <br>
    <div class="container">
    <div class="areaTabelas">

        <form method="post" action="<?php echo site_url('CrudController/updateDataNoticias')?>/<?= $row['pk_codnoticia']; ?>">

            <div class="form-group">
                <label for="exampleInputNome1">Nome</label>
                <input type="text" class="form-control" name="nome" value="<?php echo $row['nome_noticias'];?>" id="exampleInputNome1" aria-describedby="nomeHelp" placeholder="Digite o nome da vacina">
            </div>
            <div class="form-group">
                <label for="exampleInputTexto1">Chamada da Notícia</label>
                <input type="text" class="form-control" name="texto" value="<?php echo $row['texto_noticias'];?>" id="exampleInputTexto1" aria-describedby="textoHelp" placeholder="Digite a texto">
            </div>
            <div class="form-group">
                <label for="exampleInputLink1">Link</label>
                <input type="text" class="form-control" name="link" value="<?php echo $row['link_noticias'];?>" id="exampleInputLink1" aria-describedby="textoHelp" placeholder="Digite a link">
            </div>

<!--     
            <div class="form-group">
                <label for="mesmaImgEdit">Imagem</label>
                <div class="col-md-5">
                    <div>
                        <img src="<?php echo base_url('assets/imagens/noticias')?>/<?php echo $row['imagem_noticias']; ?>" class="card-img" alt="..." style="border-radius: 0px; width:100%; height: 300px">
                        <input type="hidden" id="mesmaImgEdit" name="mesmaImgEdit" value="<?php $row['imagem_noticias'];?>">
                    </div>
                    </div>
                        <small>Imagem atual</small>
                        <br>
                        <label for="editarImg">Mudar Imagem</label>
                        <input type="file" class="form-control" name="imagemNoticiaUpdate" id="imagemNoticiaUpdate" aria-describedby="imagemHelp" placeholder="Mudar Imagem">
                  </div>
            </div>
 -->

        
            <div class="modal-footer" style= "margin-bottom:5%;" >
                <a href="<?php echo site_url('InicioController/listaNoticias');?>">
                    <button type="button" class="btn btn-secondary">
                    Fechar</button>
                </a>
                <button type="submit" class="btn btn-primary" value="save">Enviar</button>
            </div>
        </form>
    </div>
</div>
  </body>
<footer class="rodape">
    <div>
      <div class="coluna1">
        <h1 class="tituloRodape">Sobre nós</h1>
        <h4 class="textoRodape" > O sistema “vacinas online” foi criado por alunos do Instituto Federal Catarinense - Campus Araquari. Vendo a realidade atual do sistema público de saúde da cidade de Araquari na pauta de vacinações temos o objetivo de facilitar o acesso e a administração das vacinas tomadas pela população para ter um melhor controle das mesmas.
        </h4>
        <h4 class="textoRodape"> Além de facilitar o acesso a informação sobre quais vacinas devem ser tomadas conforme cada idade, e informar sobre doenças em surto, campanhas e etc com a aba de notícias. </h4>
      </div>

      

      <div class="coluna2">
        <h1 class="tituloRodape">Contato</h1>
        <h4 class="textoRodape" style="  font-weight: bold;"> Email vacinasonline.ifc@outlook.com </h4>
      </div>
    </div>
    
</footer>

<div class="rodapeFinal">
    <div style="text-align: center;">
        <h4 class="textoRodape">© Vacinas Online 2019. Criado por Gabrielle Oliveira, Gustavo Bonifácio e Jenifer Santos.</h4>
      </div>
    </div>
  </div>
</div>
</footer>

</html>

</html>