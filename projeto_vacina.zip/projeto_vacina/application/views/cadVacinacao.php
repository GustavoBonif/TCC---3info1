<?php
    include('cabecalho.php');
?>

		<div style="margin: 5% 10% 0 10%">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Cadastro de Vacinas</h5>
        </div>
        <!-- inicio formulário -->
        <form method="post" action="<?php echo site_url('CrudController/createVacinacao')?>">
            <div class="modal-body">        
                <div class="form-group">
                    <label for="exampleInputnome1">Nome</label>
                    <input type="nome" class="form-control" name="nome" id="exampleInputNome1" aria-describedby="nomeHelp" placeholder="Digite seu nome">
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Email</label>
                    <input type="email" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Digite seu email">
                </div>
                <div class="form-group">
                    <label for="exampleInputSenha1">Senha</label>
                    <input type="senha" class="form-control" name="senha" id="exampleInputSenha1" placeholder="Senha">
                </div>
                <div class="form-group">
                    <label for="exampleInputCPF1">CPF</label>
                    <input type="int" class="form-control" name="cpf" id="exampleInputCPF1" placeholder="CPF">
                </div>
                <div class="form-group">
                    <label for="exampleInputRG1">RG</label>
                    <input type="int" class="form-control" name="rg" id="exampleInputRG1" placeholder="RG">
                </div>
                <p>Tipo De Usuário</p>
                <div class="form-group form-radio">
                    <input type="radio" class="form-radio-input" value="1" name="codtipuser" checked id="exampleRadio1">
                    <label class="form-radio-label" for="exampleRadio1">Comum</label>
                </div>
<!--                 <div class="form-group form-radio">
                    <input type="radio" class="form-radio-input" value="2" name="codtipuser" id="exampleRadio1">
                    <label class="form-radio-label" for="exampleRadio1">Funcionário</label>
                </div> -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                    <button type="submit" class="btn btn-primary" value="save">Enviar</button>
                </div>
            </div>
        </form>
        <!-- fim formulário -->
    </div>
    </div>

<footer class="rodape">
    <div>
      <div class="coluna1">
        <h1 class="tituloRodape">Sobre nós</h1>
        <h4 class="textoRodape" > O sistema “vacinas online” foi criado por alunos do Instituto Federal Catarinense - Campus Araquari. Vendo a realidade atual do sistema público de saúde da cidade de Araquari na pauta de vacinações temos o objetivo de facilitar o acesso e a administração das vacinas tomadas pela população para ter um melhor controle das mesmas.
        </h4>
        <h4 class="textoRodape"> Além de facilitar o acesso a informação sobre quais vacinas devem ser tomadas conforme cada idade, e informar sobre doenças em surto, campanhas e etc com a aba de notícias. </h4>
      </div>

      

      <div class="coluna2">
        <h1 class="tituloRodape">Contato</h1>
        <h4 class="textoRodape" style="  font-weight: bold;"> Email vacinasonline.ifc@outlook.com </h4>
      </div>
    </div>
    
</footer>

<div class="rodapeFinal">
    <div style="text-align: center;">
        <h4 class="textoRodape">© Vacinas Online 2019. Criado por Gabrielle Oliveira, Gustavo Bonifácio e Jenifer Santos.</h4>
      </div>
    </div>
  </div>
</div>
</footer>

</html>
