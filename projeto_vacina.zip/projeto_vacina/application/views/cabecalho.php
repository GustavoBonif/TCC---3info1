<?php

?>

<!DOCTYPE html>
<html>
<head>
	<title>Vacinas Online</title>



	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/estilo.css')?>">

   <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" type="text/css" href="css.css">

    <!-- <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/bootstrap-4.3.1-dist/js/bootstrap.min.js')?>">
 -->

    <!-- Bootstrap CSS -->

    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/bootstrap-4.3.1-dist/css/bootstrap.min.css')?>">

    <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap-4.3.1-dist/css/bootstrap.min.css')?>" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<header>
  <nav class="menuP">
  <ul class="nav justify-content" style="margin: 0%;">
  <img src="<?php echo base_url('assets/imagens/logo.png');?>" style="width:200px; height: 40px; margin: 0 15% 0 13%">

  <?php
    if(isset($_SESSION['user'])){
     
      $myvalue = $_SESSION['user']['nome_user'];
        $arr = explode(' ',trim($myvalue));

        ?>
        <li class="nav-item active" style="margin: 0%; padding: 0%" >
      <?php

        echo '<p class="nav-link menu-texto" style="margin: 0%; ">Olá '.$arr[0].'</p>';
    }
  ?>

  <li class="nav-item">
    <a class="nav-link menu-texto" href="<?php echo site_url('InicioController/index');?>">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link menu-texto" href="<?php echo site_url('InicioController/listaNoticias');?>">Notícias</a>
  </li>



<?php
    if(isset($_SESSION['user'])){
     if($_SESSION['user']['fk_codtipuser'] == 1){ ?>

      <li class="nav-item">
        <a class="nav-link menu-texto" href="<?php echo site_url('InicioController/carteiraComum');?>/<?php echo $_SESSION['user']['pk_coduser']?>" >Carteirinha Online</a>
      </li>


<?php }elseif ($_SESSION['user']['fk_codtipuser'] == 2) { ?>

        <li class="nav-item">
          <a class="nav-link menu-texto" href="<?php echo site_url('InicioController/controleCarteira');?>" >Controle da Carteirinha</a>
        </li>

<?php }elseif($_SESSION['user']['fk_codtipuser'] == 3){?>

         <li class="nav-item">
            <a class="nav-link menu-texto" href="<?php echo site_url('InicioController/controleUsers');?>" >Controle de Usuários</a>
          </li>

  <?php }
    }elseif (empty($_SESSION['user'])) {?>
      
      <li class="nav-item">
        <a class="nav-link menu-texto" href="<?php echo site_url('InicioController/redirecionar');?>" >Carteirinha Online</a>
      </li>

  <?php }?>

  <?php
    if(isset($_SESSION['user'])){
     if($_SESSION['user']['fk_codtipuser'] == 1){ ?>

      <li class="nav-item">
        <a class="nav-link menu-texto" href="<?php echo site_url('InicioController/contaViewComum');?>" >Minha Conta</a>
      </li>

  <?php }elseif ($_SESSION['user']['fk_codtipuser'] == 2) { ?>
        <li class="nav-item">
        <a class="nav-link menu-texto" href="<?php echo site_url('InicioController/contaViewFunc');?>" >Minha Conta</a>
      </li>
  <?php }elseif($_SESSION['user']['fk_codtipuser'] == 3){?>
        <li class="nav-item">
          <a class="nav-link menu-texto" href="<?php echo site_url('InicioController/contaViewAdm');?>" >Minha Conta</a>
        </li>
  <?php } ?>

    <li class="nav-item">
      <a class="nav-link menu-texto login" href="<?php echo site_url('User/logout');?>" >Sair</a>
    </li>

<?php
    }else{
  ?>
    <li class="nav-item">
      <a class="nav-link menu-texto" href="<?php echo site_url('InicioController/header_cadastro');?>" >Criar Conta</a>
    </li>
    <li class="nav-item">
      <a class="nav-link menu-texto login" data-toggle="modal" data-target="#loginModal" href="#" >Login</a>
    </li>


  <?php }?>




    <!-- Modal -->
    <div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Login de Usuário</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <form method="post" action="<?php echo site_url('User/login')?>"> <!--LOGIN INICIO -->
              <div class="modal-body">        
                <div class="form-group">
                  <label for="exampleInputemail1">Email</label>
                  <input type="email" class="form-control" name='email' id="exampleInputemail1" aria-describedby="emailHelp" placeholder="Digite seu email">
                </div>
                <div class="form-group">
                  <label for="exampleInputSenha1">Senha</label>
                  <input type="password" class="form-control" name='senha' id="exampleInputSenha1" placeholder="Senha">
                </div>

              </div>
                <div class="modal-footer">
                  <a href="<?php echo site_url('InicioController/header_cadastro');?>" style="">Ainda não possui conta? Cadastre-se</a>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                  <button type="submit" class="btn btn-primary">Logar</button>
                  <?php
                    echo $this->session->flashdata("erro");
                  ?>
                </div>
              </div>
            </form>
          </div>
      </div>
</ul>
</nav>
</header>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


  

  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>






</html>