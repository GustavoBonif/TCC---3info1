<?php

include ('cabecalho.php');

?>

<div class="col-9" style="margin: 6% 15% 0 15%">
        <div class="tab-content" id="v-pills-tabContent">
          <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                <div class="jumbotron" style="background-color: white">
                  <h1 class="display-4">Ops...</h1>
                  <p class="lead">Sua senha está incorreta</p>
                  <hr class="my-4">
                  <p>Caso ainda não seja um usuário do site faça seu cadastro agora <a href="<?php echo site_url('InicioController/header_cadastro');?>">clicando aqui</a></p>
                  <a class="btn btn-primary btn-lg text1Departamento" data-toggle="modal" data-target="#loginModal" href="#" role="button" style="border-radius: 40px">Logar</a>
                </div>              
          </div>
          </div>
        </div>
      

<footer class="rodape">
    <div>
      <div class="coluna1">
        <h1 class="tituloRodape">Sobre nós</h1>
        <h4 class="textoRodape" > O sistema “vacinas online” foi criado por alunos do Instituto Federal Catarinense - Campus Araquari. Vendo a realidade atual do sistema público de saúde da cidade de Araquari na pauta de vacinações temos o objetivo de facilitar o acesso e a administração das vacinas tomadas pela população para ter um melhor controle das mesmas.
        </h4>
        <h4 class="textoRodape"> Além de facilitar o acesso a informação sobre quais vacinas devem ser tomadas conforme cada idade, e informar sobre doenças em surto, campanhas e etc com a aba de notícias. </h4>
      </div>

      

      <div class="coluna2">
        <h1 class="tituloRodape">Contato</h1>
        <h4 class="textoRodape" style="  font-weight: bold;"> Email vacinasonline.ifc@outlook.com </h4>
      </div>
    </div>
    
</footer>

<div class="rodapeFinal">
    <div style="text-align: center;">
        <h4 class="textoRodape">© Vacinas Online 2019. Criado por Gabrielle Oliveira, Gustavo Bonifácio e Jenifer Santos.</h4>
      </div>
    </div>
  </div>
</div>
</footer>

</html>
