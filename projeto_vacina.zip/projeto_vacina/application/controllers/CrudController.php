<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CrudController extends CI_Controller {

    public function __construct(){
        parent:: __construct();
        $this->load->model('Crud_model');

    }

	public function index(){
        $data['result'] = $this->Crud_model->getAllData();
		$this->load->view('crudView', $data);
    }

    //cria usuario comum
    public function createComum() {
        $this->Crud_model->createData();
        $this->Crud_model->createComum();
        redirect("InicioController/index");
    }

    //cria usuario funcionario
    public function createFunc() {
        $this->Crud_model->createData();
        $this->Crud_model->createFuncionario();
        redirect("InicioController/controleUsers");
    }


    // edita usuario
    public function edit($coduser){
        $data['row'] = $this->Crud_model->getData($coduser);
        $data['comum'] = $this->Crud_model->getDataComum($coduser);
        $data['func'] = $this->Crud_model->getDataFunc($coduser);
        $this->load->view('crudEdit', $data);
    }

    // edita usuario comum
    public function updateDataComum($coduser){
        $this->Crud_model->updateDataComum($coduser);
        redirect("InicioController/index");
    }

    // edita usuario func
    public function updateDataFunc($coduser){
        $this->Crud_model->updateDataFunc($coduser);
        redirect("InicioController/index");
    }

    // edita usuario adm
    public function updateDataAdm($coduser){
        $this->Crud_model->updateDataAdm($coduser);
        redirect("InicioController/index");
    }

    //////////// Deleta conta usuario comum //////////////
    public function deleteContaComum($coduser){
        $this->Crud_model->deleteDataComum($coduser);
        $this->session->unset_userdata('user');
        redirect("InicioController/index");

    }

    //////////// Deleta usuario comum //////////////
    public function deleteComum($coduser){
        $this->Crud_model->deleteDataComum($coduser);
        redirect("InicioController/controleUsers");

    }

    //////////// Deleta usuario funcionario //////////////
    public function deleteFunc($coduser){
        $this->Crud_model->deleteDataFunc($coduser);
        redirect("InicioController/controleUsers");
    }


    // public function modalDelete($id){
    //     $this->load->view('modalDelete');
    // }

    ////////////////////////// VACINAS //////////////////

    public function listaVacina(){
        $data['result'] = $this->Crud_model->getAllVacinas();
        $this->load->view('listaVacina', $data);  
    }

    public function createVacina() {
        $this->Crud_model->createVacina();
        redirect("CrudController/listaVacina");
    }

    public function updateDataVacina($codvacina){
        $this->Crud_model->updateDataVacina($codvacina);
        redirect("CrudController/listaVacina");
    }

    public function editVacina($codvacina) {
        $data['row'] = $this->Crud_model->getDataVacina($codvacina);
        $this->load->view('editVacina', $data);
    }

    public function deleteVacina($codvacina){
        $this->Crud_model->deleteDataVacina($codvacina);
        redirect("CrudController/listaVacina");

    }

    ////////////////////////// NOTICIAS //////////////////

    public function createNoticia() {
        $this->Crud_model->createNoticia($_FILES);
        redirect("InicioController/listaNoticias");


    }

    public function updateDataNoticias($codnoticia){
        $this->Crud_model->updateDataNoticias($codnoticia);
        redirect("InicioController/listaNoticias");
    }

    public function editNoticias($codnoticia) {
        $data['row'] = $this->Crud_model->getDataNoticias($codnoticia);
        $this->load->view('editNoticias', $data);
    }

    public function deleteNoticias($codnoticia){
        $this->Crud_model->deleteDataNoticias($codnoticia);
        redirect("InicioController/listaNoticias");

    }

    ////////////////////////// VACINACAO //////////////////

    public function createVacinacao() {
        $this->Crud_model->createVacinacao();
        $idusuario = $idusuario;
        redirect("InicioController/controleCarteira");
    }

    public function updateDataVacinacao($codvacinacao){
        $this->Crud_model->updateDataVacinacao($codvacinacao);
        redirect("InicioController/controleCarteira");
    }

    public function editVacinacao($codvacinacao) {
        $data['vacinacao'] = $this->Crud_model->getDataVacinacao($codvacinacao);
        $data['vacinacoes'] = $this->Crud_model->getAllVacinacoes();
        $data['vacinas'] = $this->Crud_model->getAllVacinas();
        $this->load->view('editVacinacao', $data);
    }

    public function deleteVacinacao($codvacinacao){
        $this->Crud_model->deleteDataVacinacao($codvacinacao);
        redirect("InicioController/controleCarteira");
    }


}