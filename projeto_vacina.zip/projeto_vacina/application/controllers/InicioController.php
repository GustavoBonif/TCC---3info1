<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class InicioController extends CI_Controller {

    public function __construct(){
        parent:: __construct();
        $this->load->library('session');
        $this->load->model('Crud_model');

    }

	public function index(){
		$this->load->view('paginaInicial');
    }

    //cabeçalho
    public function header_cadastro(){
        $this->load->view('cadastro');
    }

    //rodape
    public function rodape(){
        $this->load->view('rodape');
    }


    public function listaNoticias(){
        $this->load->model('Crud_model');
        //load session library 
        $this->load->library('session');

        $data['result'] = $this->Crud_model->getAllNoticias();
       
        $this->load->view('noticias', $data);
    }

    public function erroLogin(){
        $this->load->view('erroLogin');
    }

    /////////// Perfil Comum ////////////// 
    public function contaViewComum(){
        $this->load->model('Crud_model');
        //load session library 
        $this->load->library('session');

        if($this->session->userdata('user')){
            $data['result'] = $this->Crud_model->getAllDataComum();
            $this->load->view('contaViewComum', $data);
          }else{
            $this->load->view('redirecionar');
          }
    }


    /////////// Perfil Funcionario ////////////// 
    public function contaViewFunc(){
        $this->load->model('Crud_model');
        //load session library 
        $this->load->library('session');

        if($this->session->userdata('user')){
            $data['result'] = $this->Crud_model->getAllDataFunc();
            $this->load->view('contaViewFunc', $data);
          }else{
            $this->load->view('redirecionar');
          }
    }

    public function cadastroVacina(){
        $this->load->view('cadVacina');  
    }

    public function listaVacina(){
        $this->load->model('Crud_model');
        $data['result'] = $this->Crud_model->getAllVacinas();
        $this->load->view('listaVacina', $data);  
    }

    public function registrarVacinacao(){
      $this->load->model('Crud_model');
      $data['result'] = $this->Crud_model->getAllVacinas();
      $this->load->view('listaVacina', $data);  


      $data['result'] = $this->Crud_model->getAllVacinacoes();
      $data['todos'] = $this->Crud_model->getAllData();
      $data['comum'] = $this->Crud_model->getAllDataComum();
      $data['func'] = $this->Crud_model->getAllDataFunc();
      $data['vacina'] = $this->Crud_model->getAllVacinas();
      $this->load->view('carteiraComum', $data);
  }
    

    /////////// Perfil Adm //////////////
    public function contaViewAdm(){
        $this->load->model('Crud_model');
        //load session library
        $this->load->library('session');

        if($this->session->userdata('user')){
            $data['result'] = $this->Crud_model->getAllData();
            $this->load->view('contaViewAdm', $data);
          }else{
            $this->load->view('redirecionar');
          }
    }    


    public function controleUsers(){

        //load session library
        $this->load->library('session');

        if($this->session->userdata('user')){
            $data['todos'] = $this->Crud_model->getAllData();
            $data['func'] = $this->Crud_model->getAllDataFunc();
            $data['comum'] = $this->Crud_model->getAllDataComum();
            $this->load->view('controleUsers', $data);
        }else{
            $this->load->view('redirecionar');
        }
    }

    public function contaView(){
        $this->load->model('Crud_model');
        //load session library
        $this->load->library('session');

        if($this->session->userdata('user')){
            $data['result'] = $this->Crud_model->getAllData();
            $this->load->view('contaView', $data);
          }else{
            $this->load->view('redirecionar');
          }
    }

    public function header_login(){
        $this->load->view('login');
    }

    public function redirecionar(){
        $this->load->view('redirecionar');
    }


    /////////// Carteira de Vacinação ////////////// 

    public function carteiraComum($idusuario){
        $this->load->model('Crud_model');
        //load session library 
        $this->load->library('session');

        if($this->session->userdata('user')){
            $data['vacinacao'] = $this->Crud_model->getAllVacinacoes();
            $data['todos'] = $this->Crud_model->getAllData();
            $data['comum'] = $this->Crud_model->getAllDataComum();
            $data['func'] = $this->Crud_model->getAllDataFunc();
            $data['vacina'] = $this->Crud_model->getAllVacinas();
            $data['idusuario'] = $idusuario;
            $this->load->view('carteiraComum', $data);
          }else{
            $this->load->view('redirecionar');
          }
    }

    public function controleCarteira(){
        $this->load->model('Crud_model');
        //load session library 
        $this->load->library('session');

        if($this->session->userdata('user')){
            $data['result'] = $this->Crud_model->getAllVacinacoes();
            $data['todos'] = $this->Crud_model->getAllData();
            $data['comum'] = $this->Crud_model->getAllDataComum();
            $data['func'] = $this->Crud_model->getAllDataFunc();
            $data['vacina'] = $this->Crud_model->getAllVacinas();
            $this->load->view('carteiraFunc', $data);
          }else{
            $this->load->view('redirecionar');
          }
    }


    // BUSCAS
    
     // busca comum quando como func
    public function buscaUserComum(){
        $this->load->model('Crud_model');
        //load session library 
        $this->load->library('session');

        if($this->session->userdata('user')){
            $data['result'] = $this->Crud_model->getAllVacinacoes();
            $data['todos'] = $this->Crud_model->getAllData();
            $data['comum'] = $this->Crud_model->getAllDataComum();
            $data['func'] = $this->Crud_model->getAllDataFunc();
            $data['vacina'] = $this->Crud_model->getAllVacinas();
            $this->load->view('buscaUserComum', $data);
          }else{
            $this->load->view('redirecionar');
          }
    }

     // busca comum no controle de users
    public function resultadoControleBuscaComum(){
        $this->load->model('Crud_model');
        //load session library 
        $this->load->library('session');

        if($this->session->userdata('user')){
            $data['result'] = $this->Crud_model->getAllVacinacoes();
            $data['todos'] = $this->Crud_model->getAllData();
            $data['comum'] = $this->Crud_model->getAllDataComum();
            $data['func'] = $this->Crud_model->getAllDataFunc();
            $data['vacina'] = $this->Crud_model->getAllVacinas();
            $this->load->view('buscaControleComum', $data);
          }else{
            $this->load->view('redirecionar');
          }
    }

    // busca funcionarios no controle de users
    public function resultadoControleBuscaFunc(){
        $this->load->model('Crud_model');
        //load session library 
        $this->load->library('session');

        if($this->session->userdata('user')){
            $data['result'] = $this->Crud_model->getAllVacinacoes();
            $data['todos'] = $this->Crud_model->getAllData();
            $data['comum'] = $this->Crud_model->getAllDataComum();
            $data['func'] = $this->Crud_model->getAllDataFunc();
            $data['vacina'] = $this->Crud_model->getAllVacinas();
            $this->load->view('buscaControleFunc', $data);
          }else{
            $this->load->view('redirecionar');
          }
    }

    // busca funcionarios no controle de users
    public function resultadoBuscaVacinas(){
        $this->load->model('Crud_model');
        //load session library 
        $this->load->library('session');

        if($this->session->userdata('user')){
            $data['result'] = $this->Crud_model->getAllVacinacoes();
            $data['todos'] = $this->Crud_model->getAllData();
            $data['comum'] = $this->Crud_model->getAllDataComum();
            $data['func'] = $this->Crud_model->getAllDataFunc();
            $data['vacinas'] = $this->Crud_model->getAllVacinas();
            $this->load->view('buscaVacinas', $data);
          }else{
            $this->load->view('redirecionar');
          }
    }


}
 