<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud_model extends CI_Model {

    public function __construct(){
        $this->load->database();
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
    }


/////////// CREATE USER COMUM ////////////////
    function createData(){
        //$senha = md5($this->input->post('senha'));
        $senha = $this->input->post('senha');
        $data = array (
            'email_user' => $this->input->post('email'),
            'senha_user' => $senha,
            'nome_user' => $this->input->post('nome'),
            'fk_codtipuser' => $this->input->post('codtipuser')
        );
        $this->db->insert('user', $data);
    }


//////////////////////////////// TESTE LAST INSERT ID /////////////////////////////////

    function createComum(){

        $rg = $this->input->post('rg');
        $cpf = $this->input->post('cpf');
        $this->db->query("SET @last_id = LAST_INSERT_ID()");

        $sql = "insert into usercomum (rg_usercomum, fk_coduser, pk_cpf_usercomum) values ($rg, @last_id, $cpf)";
        $this->db->query($sql);
    }

////////////////////////////////////////////////////////////////////////////////////


/////////// CREATE USER FUNCIONARIO ////////////////
    function createFuncionario(){

        $localtrab = $this->input->post('localtrab');
        $cpf = $this->input->post('cpf');
        $this->db->query("SET @last_id = LAST_INSERT_ID()");

        $sql = "insert into userfuncionario (localtrab_userfunc, fk_coduser, cpf_userfunc) values ('$localtrab', @last_id, $cpf)";

        $this->db->query($sql);


    }


    function getAllData(){
        $query = $this->db->query('select * from user');
        return $query->result();
    }

    function getAllDataComum(){
        $query = $this->db->query('select * from usercomum');
        return $query->result();
    }

    function getAllDataFunc(){
        $query = $this->db->query('select * from userfuncionario');
        return $query->result();
    }

    function getData($coduser){
        $query = $this->db->query('select * from user where pk_coduser = ' .$coduser);
        return $query->row();
    }

    function getDataComum($coduser){
        $query = $this->db->query('select * from usercomum where fk_coduser =' .$coduser);
        return $query->row();
    }

    function getDataFunc($coduser){
        $query = $this->db->query('select * from userfuncionario where fk_coduser =' .$coduser);
        return $query->row();
    }

    //////////// Atualiza usuario comum //////////////
    function updateDataComum($coduser){
        $this->load->library('session');

        $data = array (
            'email_user' => $this->input->post('email'),
            'senha_user' => $this->input->post('senha'),
            'nome_user' => $this->input->post('nome'),
            'fk_codtipuser' => 1,
            'pk_coduser' => $coduser
        );
        $this->db->where('pk_coduser', $coduser);
        $this->db->update('user', $data);

        $this->session->set_userdata('user', $data);

        $dados = array (
            'rg_usercomum' => $this->input->post('rg'),
            'pk_cpf_usercomum' => $this->input->post('cpf')
        );
        $this->db->where('fk_coduser', $coduser);
        $this->db->update('usercomum', $dados);
    }

    //////////// Atualiza usuario funcionario //////////////
    function updateDataFunc($coduser){
        $this->load->library('session');

        $data = array (
            'email_user' => $this->input->post('email'),
            'senha_user' => $this->input->post('senha'),
            'nome_user' => $this->input->post('nome'),
            'fk_codtipuser' => 2,
            'pk_coduser' => $coduser
        );
        $this->db->where('pk_coduser', $coduser);
        $this->db->update('user', $data);

        $this->session->set_userdata('user', $data);

        $dados = array (
            'localtrab_userfunc	' => $this->input->post('localtrab'),
            'cpf_userfunc' => $this->input->post('cpf')
        );
        $this->db->where('fk_coduser', $coduser);
        $this->db->update('userfuncionario', $dados);
    }

    //////////// Atualiza usuario adm //////////////
    function updateDataAdm($coduser){
        $this->load->library('session');
        
        $data = array (
            'email_user' => $this->input->post('email'),
            'senha_user' => $this->input->post('senha'),
            'nome_user' => $this->input->post('nome'),
            'fk_codtipuser' => 3,
            'pk_coduser' => $coduser
        );
        $this->db->where('pk_coduser', $coduser);
        $this->db->update('user', $data);

        $this->session->set_userdata('user', $data);

    }



    //////////// Deleta usuario comum //////////////
    function deleteDataComum($coduser){  
        $this->db->where('fk_coduser', $coduser);
        $this->db->delete('usercomum');
        $this->db->where('pk_coduser', $coduser);
        $this->db->delete('user');
    }

    //////////// Deleta usuario funcionario //////////////
    function deleteDataFunc($coduser){
        echo $coduser;
        $this->db->where('fk_coduser', $coduser);
        $this->db->delete('userfuncionario');
        $this->db->where('pk_coduser', $coduser);
        $this->db->delete('user');
    }


    ////////////////////////// VACINAS //////////////////



    function getAllVacinas(){
        $query = $this->db->query('select * from vacina');
        return $query->result();
    }

    function getDataVacina($codvacina){

        $query = $this->db->get_where('vacina', array('pk_codvacina' => $codvacina));
        return $query->row_array();
    }

    function updateDataVacina($codvacina){
        $data = array (
            'nome_vacina' => $this->input->post('nome'),
            'descricao_vacina' => $this->input->post('descricao'),
            'dose_vacina' => $this->input->post('dose'),
            'idade_vacina' => $this->input->post('idade')
        );
        $this->db->where('pk_codvacina', $codvacina);
        $this->db->update('vacina', $data);
    }

    function createVacina(){
        $data = array (
            'nome_vacina' => $this->input->post('nome'),
            'descricao_vacina' => $this->input->post('descricao'),
            'dose_vacina' => $this->input->post('dose'),
            'idade_vacina' => $this->input->post('idade')
        );
        $this->db->insert('vacina', $data);
    }

    function deleteDataVacina($codvacina){
        $this->db->where('pk_codvacina', $codvacina);
        $this->db->delete('vacina');
    } 


    ////////////////////////// NOTICIAS //////////////////

    function getAllNoticias(){
        $query = $this->db->query('select * from noticias');
        return $query->result();
    }


    function getDataNoticias($codnoticia){
        $query = $this->db->get_where('noticias', array('pk_codnoticia' => $codnoticia));
        return $query->row_array();
    }


    // CRIA NOTICIAS
    function createNoticia($file){
       
        $caminho_temporario = $_FILES['imagemNoticia']['tmp_name'];
        $destino = base_url('assets/imagens/noticias/').$caminho_temporario;

        $extensao = pathinfo($_FILES['imagemNoticia']['name'], PATHINFO_EXTENSION);
        $nome_arquivo = md5(uniqid($_FILES['imagemNoticia']['name'])) . "." . $extensao;



        $target_dir = BASEPATH.("../assets/imagens/noticias/");

        if (move_uploaded_file($file["imagemNoticia"]["tmp_name"], $target_dir.$nome_arquivo)) {
             echo "The file ".basename($_FILES["imagemNoticia"]["name"])." has been uploaded";
            echo "deu";
        }else{
            echo "nao deu";
        }

        $config['upload_path'] = './assets/imagens/noticias/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '10000';
        $config['max_width']  = '102400';
        $config['max_height']  = '76800';

            $data = array (
                'nome_noticias' => $this->input->post('nome'),
                'texto_noticias' => $this->input->post('texto'),
                'link_noticias' => $this->input->post('link'),
                'imagem_noticias'=> $nome_arquivo,
            );

        
            $this->db->insert('noticias', $data);
        
    }

    function updateDataNoticias($codnoticia){
        // CODIGO SUPOSTAMENTE FUNCIONAL

        // $data = array (
        //     'nome_noticias' => $this->input->post('nome'),
        //     'texto_noticias' => $this->input->post('texto')
        // );

        // if ($_FILES['imagemNoticiaUpdate'] != NULL) {
        //     $extensao = pathinfo($_FILES['imagemNoticiaUpdate']['name'], PATHINFO_EXTENSION);
        //     $nome_arquivo = md5(uniqid($_FILES['imagemNoticiaUpdate']['name'])) . "." . $extensao;
        //     $diretorio = "assets/imagens/noticias/";
        //     $caminho_temporario = $_FILES['imagemNoticiaUpdate']['tmp_name'];
            

        //     move_uploaded_file($caminho_temporario, $diretorio. $nome_arquivo);

        //     $data['imagem_noticias'] = $nome_arquivo;

        //     $row = $this->getDataNoticias($cpf);
        //     if (condition) {
        //         # code...
        //     }













        // MEU CODIGO NÃO FUNCIONAL
        // if ($_FILES['imagemNoticiaUpdate']['name'] != NULL) {
        //     $caminho_temporario = $_FILES['mesmaImgEdit']['tmp_name'];
        //     $destino = base_url('assets/imagens/noticias/').$caminho_temporario;
    
        //     $extensao = pathinfo($_FILES['mesmaImgEdit']['name'], PATHINFO_EXTENSION);
        //     $nome_arquivo = md5(uniqid($_FILES['mesmaImgEdit']['name'])) . "." . $extensao;

        //     $img_update = $nome_arquivo;
        // }else{
       
        //     $caminho_temporario = $_FILES['imagemNoticiaUpdate']['tmp_name'];
        //     $destino = base_url('assets/imagens/noticias/').$caminho_temporario;
    
        //     $extensao = pathinfo($_FILES['imagemNoticiaUpdate']['name'], PATHINFO_EXTENSION);
        //     $nome_arquivo = md5(uniqid($_FILES['imagemNoticiaUpdate']['name'])) . "." . $extensao;
    
        //     $img_update = $nome_arquivo;
        // }


        // $target_dir = BASEPATH.("../assets/imagens/noticias/");

        // if (move_uploaded_file($file["imagemNoticiaUpdate"]["tmp_name"], $target_dir.$nome_arquivo)) {
        //      echo "O arquivo ".basename($_FILES["imagemNoticiaUpdate"]["name"])." foi enviado com sucesso";
        //     echo "deu";
        // }else{
        //     echo "nao deu";
        // }
        


        $data = array (
            'nome_noticias' => $this->input->post('nome'),
            'texto_noticias' => $this->input->post('texto'),
            'link_noticias' => $this->input->post('link')
            //'imagem_noticias' => $img_update
        );
        $this->db->where('pk_codnoticia', $codnoticia);
        $this->db->update('noticias', $data);
    }


    function deleteDataNoticias($codnoticia){
        $this->db->where('pk_codnoticia', $codnoticia);
        $this->db->delete('noticias');
    }



////////////// Carteira de Vacinação //////////////////



    function getAllVacinacoes(){
        $query = $this->db->query('select * from vacinacao');
        return $query->result();
    }

    
    function createVacinacao(){

        $agenda = date("d/m/Y");

        $data = array (
            'fk_codfunc' => $this->input->post('codfunc'),
            'fk_codvacina' => $this->input->post('codvacina'),
            'fk_cpf' => $this->input->post('cpf'),
            'data_vacinacao' => $agenda,
            'dose_vacinacao' => $this->input->post('dose')
        );
        $idusuario = $this->input->post('coduser');
        // $this->db->insert('vacinacao', $data, $idusuario);
        $this->db->insert('vacinacao', $data);

    
    }

    function getDataVacinacao($codvacinacao){
        $query = $this->db->get_where('vacinacao', array('pk_codvacinacao' => $codvacinacao));
        return $query->row_array();
    }

    function updateDataVacinacao($codvacinacao){
        $data = array (
            'fk_codfunc' => $this->input->post('codfunc'),
            'fk_codvacina' => $this->input->post('codvacina'),
            'fk_cpf' => $this->input->post('cpf'),
            'data_vacinacao' => $this->input->post('data'),
            'dose_vacinacao' => $this->input->post('dose'),
        );
        $this->db->where('pk_codvacinacao', $codvacinacao);
        $this->db->update('vacinacao', $data);
    }

    function deleteDataVacinacao($codvacinacao){
        $this->db->where('pk_codvacinacao', $codvacinacao);
        $this->db->delete('vacinacao');
    } 

}
