<?php
class Users_model extends CI_Model {

    function __construct(){
        parent::__construct();
        $this->load->database();
    }


    public function login($email, $senha){
        $senha = $senha;
        $query = $this->db->get_where('user', array('email_user'=>$email, 'senha_user'=>$senha));

        return $query->row_array();
    }
}
?>