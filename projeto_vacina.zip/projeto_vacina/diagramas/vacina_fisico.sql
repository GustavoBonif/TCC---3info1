-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE tipuser (
descricao varchar(200),
codtipuser int not null auto_increment PRIMARY KEY
);

CREATE TABLE usercomum (
rg int,
cpf int not null PRIMARY KEY,
coduser int
);

CREATE TABLE noticias (
nome varchar(200),
texto varchar(3000),
codnoticia int not null auto_increment PRIMARY KEY
);

CREATE TABLE publica (
coduser int,
codnoticia int,
FOREIGN KEY(codnoticia) REFERENCES noticias (codnoticia)
);

CREATE TABLE vacina (
descricao varchar(400),
nome varchar(100),
codvacina int not null auto_increment PRIMARY KEY,
dose int,
idade varchar(20),
coduser int
);

CREATE TABLE vacinacao (
codfunc int,
codvacina int,
cpf int,
data date,
dose int,
codvacinacao int not null auto_increment PRIMARY KEY,
FOREIGN KEY(codvacina) REFERENCES vacina (codvacina),
FOREIGN KEY(cpf) REFERENCES usercomum (cpf)
);

CREATE TABLE user (
email varchar(200),
senha varchar(20),
coduser int not null auto_increment PRIMARY KEY,
nome varchar(100),
codtipuser int,
FOREIGN KEY(codtipuser) REFERENCES tipuser (codtipuser)
);

CREATE TABLE userfuncionario (
localtrab varchar(50),
codfunc int not null auto_increment PRIMARY KEY,
coduser int,
cpf int,
FOREIGN KEY(coduser) REFERENCES user (coduser)
);

ALTER TABLE usercomum ADD FOREIGN KEY(coduser) REFERENCES user (coduser);
ALTER TABLE publica ADD FOREIGN KEY(coduser) REFERENCES user (coduser);
ALTER TABLE vacina ADD FOREIGN KEY(coduser) REFERENCES user (coduser);
ALTER TABLE vacinacao ADD FOREIGN KEY(codfunc) REFERENCES userfuncionario (codfunc);
