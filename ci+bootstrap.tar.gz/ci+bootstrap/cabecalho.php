<!DOCTYPE html>
<html>
<head>
	<title>Vacinas Online</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/estilo.css">

<ul class="nav justify-content" style="margin: 1% 0 1% 0">
  <img src="imagens/logo.png" style="width:200px; height: 40px; margin: 0 22% 0 15%">

  <li class="nav-item">
    <a class="nav-link active" href="#">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link menu-texto" href="#">Notícias</a>
  </li>
  <li class="nav-item">
    <a class="nav-link menu-texto" href="#" >Carteirinha Online</a>
  </li>
   <li class="nav-item">
    <a class="nav-link menu-texto" href="#" >Cadastro</a>
  </li>
   <li class="nav-item">
    <a class="nav-link menu-texto login" href="login.php" >Login</a>
  </li>
   
 
</ul>

</head>
<body>
<div id="teste"></div>
</body>


<?php
	include('rodape.php');

?>

</html>

