<?php

include ('cabecalho.php');

?>

<div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="imagens/1.jpg" alt="Primeiro Slide">
        <div class="carousel-caption d-none d-md-block">
		    <h5>1111111111111111</h5>
		    <p>ASADJSKDJSKDJKS</p>
		</div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="imagens/2.jpg">
      	<div class="carousel-caption d-none d-md-block">
		    <h5>2222222222222</h5>
		    <p>ASADJSKDJSKDJKS</p>
		</div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="imagens/3.jpg">
      <div class="carousel-caption d-none d-md-block">
		    <h5>3333333333333</h5>
		    <p>ASADJSKDJSKDJKS</p>
		</div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Anterior</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Próximo</span>
  </a>
</div>